@extends('layouts.admin')  <!-- Use the admin layout -->

@section('content')
<div class="row">
    <div class="col-lg-12">
        <h2>Admin Dashboard</h2>
        <p>Welcome to the admin panel. Manage applications and users here.</p>
    </div>
</div>
@endsection
