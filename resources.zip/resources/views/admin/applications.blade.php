@extends('layouts.admin')

@section('content')

<style>
@import url('https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@300;400;500;600;700&family=Playfair+Display:wght@500;600;700&display=swap');

* {
    font-family: 'Libre Franklin', -apple-system, BlinkMacSystemFont, sans-serif;
}

/* Custom scrollbar for table */
.table-scroll::-webkit-scrollbar {
    height: 8px;
}
.table-scroll::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 10px;
}
.table-scroll::-webkit-scrollbar-thumb {
    background: #006633;
    border-radius: 10px;
}
.table-scroll::-webkit-scrollbar-thumb:hover {
    background: #004d26;
}
</style>

<!-- Main Wrapper -->
<div class="min-h-screen bg-gradient-to-br from-[#FFFEF7] via-[#f0f7f0] to-[#FEFDFB] py-4 sm:py-6 lg:py-8 px-3 sm:px-4 lg:px-6 relative">
    <!-- Decorative Background -->
    <div class="absolute top-0 left-0 right-0 h-[300px] pointer-events-none">
        <div class="absolute top-0 left-[20%] w-[40%] h-[50%] bg-[#006633]/3 rounded-full blur-3xl"></div>
        <div class="absolute top-0 right-[20%] w-[30%] h-[40%] bg-[#D4AF37]/4 rounded-full blur-3xl"></div>
    </div>

    <!-- Main Card Container -->
    <div class="max-w-7xl mx-auto relative">
        <div class="bg-[#FEFDFB] rounded-2xl shadow-lg shadow-[#006633]/8 border border-[#006633]/12 overflow-hidden">
            
            {{-- Card Header --}}
            <div class="relative bg-gradient-to-r from-[#006633] to-[#004d26] px-4 sm:px-6 lg:px-8 py-5 sm:py-6 lg:py-7 overflow-hidden">
                <!-- Decorative Elements -->
                <div class="absolute -top-1/2 -right-[10%] w-[200px] h-[200px] bg-[#FFD700]/15 rounded-full blur-3xl pointer-events-none"></div>
                <div class="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-[#FFD700] via-[#D4AF37] to-[#FFD700]"></div>
                
                <!-- Header Content -->
                <div class="relative z-10">
                    <h5 class="text-white font-bold text-xl sm:text-2xl lg:text-3xl flex items-center gap-3 mb-2" style="font-family: 'Playfair Display', serif;">
                        <i class="fa fa-file-text text-[#FFD700]"></i>
                        <span>Application Management</span>
                    </h5>
                    <p class="text-white/85 text-xs sm:text-sm">Review and manage all ETEEAP applications</p>
                </div>
            </div>

            {{-- Card Body --}}
            <div class="p-4 sm:p-6 lg:p-8">
                
                {{-- Alerts --}}
                @if(session('success'))
                <div class="mb-6 flex items-start gap-3 bg-gradient-to-r from-[#dcfce7] to-[#bbf7d0] border-l-4 border-[#166534] rounded-xl p-4 text-[#166534]">
                    <i class="fa fa-check-circle text-lg flex-shrink-0 mt-0.5"></i>
                    <span class="font-medium text-sm sm:text-base">{{ session('success') }}</span>
                </div>
                @endif

                @if(session('error'))
                <div class="mb-6 flex items-start gap-3 bg-gradient-to-r from-[#fee2e2] to-[#fecaca] border-l-4 border-[#991b1b] rounded-xl p-4 text-[#991b1b]">
                    <i class="fa fa-exclamation-circle text-lg flex-shrink-0 mt-0.5"></i>
                    <span class="font-medium text-sm sm:text-base">{{ session('error') }}</span>
                </div>
                @endif

                {{-- Search Bar --}}
                <div class="relative mb-6">
                    <i class="fa fa-search absolute left-5 top-1/2 -translate-y-1/2 text-[#006633] opacity-70"></i>
                    <input 
                        type="text" 
                        id="searchBar" 
                        placeholder="Search by name or ID..." 
                        class="w-full pl-12 pr-6 py-3 sm:py-4 border-2 border-[#006633]/12 rounded-full text-sm sm:text-base bg-white text-[#1a2e1a] transition-all duration-300 focus:outline-none focus:border-[#006633] focus:ring-4 focus:ring-[#006633]/10">
                </div>

                {{-- Controls: Tabs + Export --}}
                <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8 pb-6 border-b border-[#006633]/12">
                    
                    {{-- Tab Buttons --}}
                    <div class="flex flex-wrap gap-2 bg-gray-100 p-1.5 rounded-full w-full sm:w-auto">
                        <button 
                            class="clsu-tab-btn clsu-tab-pending active flex items-center gap-2 px-4 sm:px-6 py-2.5 sm:py-3 rounded-full font-semibold text-xs sm:text-sm transition-all duration-200" 
                            data-tab="pending" 
                            onclick="showTab('pending')">
                            <i class="fa fa-clock"></i>
                            <span class="hidden xs:inline">Pending</span>
                            <span class="bg-white/25 px-2 py-0.5 rounded-full text-[0.7rem]">{{ $pendingApplications->count() }}</span>
                        </button>
                        
                        <button 
                            class="clsu-tab-btn clsu-tab-accepted flex items-center gap-2 px-4 sm:px-6 py-2.5 sm:py-3 rounded-full font-semibold text-xs sm:text-sm transition-all duration-200" 
                            data-tab="accepted" 
                            onclick="showTab('accepted')">
                            <i class="fa fa-check"></i>
                            <span class="hidden xs:inline">Accepted</span>
                            <span class="bg-white/25 px-2 py-0.5 rounded-full text-[0.7rem]">{{ $acceptedApplications->count() }}</span>
                        </button>
                        
                        <button 
                            class="clsu-tab-btn clsu-tab-rejected flex items-center gap-2 px-4 sm:px-6 py-2.5 sm:py-3 rounded-full font-semibold text-xs sm:text-sm transition-all duration-200" 
                            data-tab="rejected" 
                            onclick="showTab('rejected')">
                            <i class="fa fa-times"></i>
                            <span class="hidden xs:inline">Rejected</span>
                            <span class="bg-white/25 px-2 py-0.5 rounded-full text-[0.7rem]">{{ $rejectedApplications->count() }}</span>
                        </button>
                    </div>

                    {{-- Export Button Dropdown --}}
                    <div class="dropdown">
                        <button 
                            class="flex items-center gap-2 bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#004d26] px-4 sm:px-5 py-2.5 sm:py-3 rounded-xl font-semibold text-xs sm:text-sm hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 w-full sm:w-auto justify-center" 
                            type="button" 
                            data-bs-toggle="dropdown" 
                            aria-expanded="false">
                            <i class="fa fa-download"></i>
                            <span>Export Data</span>
                            <i class="fa fa-chevron-down text-[0.7rem] ml-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end border-0 shadow-2xl rounded-xl p-2 mt-2">
                            <li>
                                <a class="dropdown-item px-4 py-2.5 rounded-lg hover:bg-[#006633] hover:text-white transition-colors duration-200 flex items-center gap-2 text-sm font-medium" href="{{ route('admin.application.export') }}">
                                    <i class="fa fa-file-excel text-green-600"></i>
                                    Export All Applications
                                </a>
                            </li>
                            <li><hr class="dropdown-divider my-2"></li>
                            <li>
                                <a class="dropdown-item px-4 py-2.5 rounded-lg hover:bg-[#006633] hover:text-white transition-colors duration-200 flex items-center gap-2 text-sm font-medium" href="{{ route('admin.application.export.pending') }}">
                                    <i class="fa fa-clock text-blue-600"></i>
                                    Export Pending
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item px-4 py-2.5 rounded-lg hover:bg-[#006633] hover:text-white transition-colors duration-200 flex items-center gap-2 text-sm font-medium" href="{{ route('admin.application.export.accepted') }}">
                                    <i class="fa fa-check text-green-600"></i>
                                    Export Accepted
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item px-4 py-2.5 rounded-lg hover:bg-[#006633] hover:text-white transition-colors duration-200 flex items-center gap-2 text-sm font-medium" href="{{ route('admin.application.export.rejected') }}">
                                    <i class="fa fa-times text-red-600"></i>
                                    Export Rejected
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>

                {{-- ========== PENDING TAB ========== --}}
                <div id="pending" class="tab-content">
                    @if($pendingApplications->count() > 0)
                    <div class="overflow-x-auto table-scroll rounded-xl border border-[#006633]/12">
                        <table class="min-w-full bg-white">
                            <thead class="bg-gradient-to-r from-[#006633] to-[#004d26] text-white">
                                <tr>
                                    <th class="px-4 py-3 text-left text-xs sm:text-sm font-semibold uppercase tracking-wider whitespace-nowrap">ID</th>
                                    <th class="px-4 py-3 text-left text-xs sm:text-sm font-semibold uppercase tracking-wider whitespace-nowrap">Applicant Name</th>
                                    <th class="px-4 py-3 text-left text-xs sm:text-sm font-semibold uppercase tracking-wider whitespace-nowrap">Status</th>
                                    <th class="px-4 py-3 text-center text-xs sm:text-sm font-semibold uppercase tracking-wider whitespace-nowrap">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100">
                                @foreach($pendingApplications as $application)
                                <tr class="searchable-row hover:bg-gray-50 transition-colors duration-150">
                                    <td class="px-4 py-4">
                                        <span class="applicant-id text-[#006633] font-semibold text-sm">{{ $application->user->unique_id ?? $application->user_id }}</span>
                                    </td>
                                    <td class="px-4 py-4">
                                        <span class="applicant-name text-gray-900 font-medium text-sm">{{ $application->first_name }} {{ $application->middle_name }} {{ $application->last_name }}</span>
                                    </td>
                                    <td class="px-4 py-4">
                                        <span class="inline-flex items-center gap-1.5 bg-blue-100 text-blue-700 px-3 py-1.5 rounded-full text-xs font-semibold">
                                            <i class="fa fa-clock"></i>
                                            {{ $application->status }}
                                        </span>
                                    </td>
                                    <td class="px-4 py-4">
                                        <div class="flex flex-wrap gap-2 justify-center">
                                            <button 
                                                type="button" 
                                                class="inline-flex items-center gap-1.5 bg-gradient-to-r from-[#008844] to-[#006633] text-white px-3 sm:px-4 py-2 rounded-lg text-xs font-semibold hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200"
                                                data-bs-toggle="modal" 
                                                data-bs-target="#acceptModal-{{ $application->id }}">
                                                <i class="fa fa-check"></i>
                                                <span class="hidden sm:inline">Accept</span>
                                            </button>
                                            
                                            <button 
                                                type="button" 
                                                class="inline-flex items-center gap-1.5 bg-gradient-to-r from-[#ef4444] to-[#dc2626] text-white px-3 sm:px-4 py-2 rounded-lg text-xs font-semibold hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200"
                                                data-bs-toggle="modal" 
                                                data-bs-target="#rejectModal-{{ $application->id }}">
                                                <i class="fa fa-times"></i>
                                                <span class="hidden sm:inline">Reject</span>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    
                    {{-- Pagination for Pending --}}
                    <div class="flex flex-col sm:flex-row items-center justify-between gap-4 mt-6">
                        <div class="text-xs md:text-sm text-gray-600 order-1">
                            Showing <span id="pending-start" class="font-semibold">1</span> to <span id="pending-end" class="font-semibold">10</span> of <span id="pending-total" class="font-semibold">{{ $pendingApplications->count() }}</span> applications
                        </div>
                        <div class="flex items-center gap-1 md:gap-2 order-2">
                            <button type="button" onclick="changePage('pending', -1)" class="px-2 md:px-3 py-1.5 md:py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm" id="pending-prev">
                                <i class="fa fa-chevron-left"></i>
                            </button>
                            <div id="pending-pages" class="flex items-center gap-1"></div>
                            <button type="button" onclick="changePage('pending', 1)" class="px-2 md:px-3 py-1.5 md:py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm" id="pending-next">
                                <i class="fa fa-chevron-right"></i>
                            </button>
                        </div>
                    </div>
                    @else
                    <div class="flex flex-col items-center justify-center py-16 text-gray-400">
                        <i class="fa fa-inbox text-5xl sm:text-6xl mb-4 opacity-30"></i>
                        <p class="text-base sm:text-lg font-medium">No pending applications</p>
                    </div>
                    @endif
                </div>

                {{-- ========== ACCEPTED TAB ========== --}}
                <div id="accepted" class="tab-content" style="display: none;">
                    @if($acceptedApplications->count() > 0)
                    <div class="overflow-x-auto table-scroll rounded-xl border border-[#006633]/12">
                        <table class="min-w-full bg-white">
                            <thead class="bg-gradient-to-r from-[#006633] to-[#004d26] text-white">
                                <tr>
                                    <th class="px-4 py-3 text-left text-xs sm:text-sm font-semibold uppercase tracking-wider whitespace-nowrap">ID</th>
                                    <th class="px-4 py-3 text-left text-xs sm:text-sm font-semibold uppercase tracking-wider whitespace-nowrap">Applicant Name</th>
                                    <th class="px-4 py-3 text-left text-xs sm:text-sm font-semibold uppercase tracking-wider whitespace-nowrap">Status</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100">
                                @foreach($acceptedApplications as $application)
                                <tr class="searchable-row hover:bg-gray-50 transition-colors duration-150">
                                    <td class="px-4 py-4">
                                        <span class="applicant-id text-[#006633] font-semibold text-sm">{{ $application->user->unique_id ?? $application->user_id }}</span>
                                    </td>
                                    <td class="px-4 py-4">
                                        <span class="applicant-name text-gray-900 font-medium text-sm">{{ $application->first_name }} {{ $application->middle_name }} {{ $application->last_name }}</span>
                                    </td>
                                    <td class="px-4 py-4">
                                        <span class="inline-flex items-center gap-1.5 bg-green-100 text-green-700 px-3 py-1.5 rounded-full text-xs font-semibold">
                                            <i class="fa fa-check"></i>
                                            {{ $application->status }}
                                        </span>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    
                    {{-- Pagination for Accepted --}}
                    <div class="flex flex-col sm:flex-row items-center justify-between gap-4 mt-6">
                        <div class="text-xs md:text-sm text-gray-600 order-1">
                            Showing <span id="accepted-start" class="font-semibold">1</span> to <span id="accepted-end" class="font-semibold">10</span> of <span id="accepted-total" class="font-semibold">{{ $acceptedApplications->count() }}</span> applications
                        </div>
                        <div class="flex items-center gap-1 md:gap-2 order-2">
                            <button type="button" onclick="changePage('accepted', -1)" class="px-2 md:px-3 py-1.5 md:py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm" id="accepted-prev">
                                <i class="fa fa-chevron-left"></i>
                            </button>
                            <div id="accepted-pages" class="flex items-center gap-1"></div>
                            <button type="button" onclick="changePage('accepted', 1)" class="px-2 md:px-3 py-1.5 md:py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm" id="accepted-next">
                                <i class="fa fa-chevron-right"></i>
                            </button>
                        </div>
                    </div>
                    @else
                    <div class="flex flex-col items-center justify-center py-16 text-gray-400">
                        <i class="fa fa-check-circle text-5xl sm:text-6xl mb-4 opacity-30"></i>
                        <p class="text-base sm:text-lg font-medium">No accepted applications</p>
                    </div>
                    @endif
                </div>

                {{-- ========== REJECTED TAB ========== --}}
                <div id="rejected" class="tab-content" style="display: none;">
                    @if($rejectedApplications->count() > 0)
                    <div class="overflow-x-auto table-scroll rounded-xl border border-[#006633]/12">
                        <table class="min-w-full bg-white">
                            <thead class="bg-gradient-to-r from-[#006633] to-[#004d26] text-white">
                                <tr>
                                    <th class="px-4 py-3 text-left text-xs sm:text-sm font-semibold uppercase tracking-wider whitespace-nowrap">ID</th>
                                    <th class="px-4 py-3 text-left text-xs sm:text-sm font-semibold uppercase tracking-wider whitespace-nowrap">Applicant Name</th>
                                    <th class="px-4 py-3 text-left text-xs sm:text-sm font-semibold uppercase tracking-wider whitespace-nowrap">Status</th>
                                    <th class="px-4 py-3 text-left text-xs sm:text-sm font-semibold uppercase tracking-wider whitespace-nowrap">Remarks</th>
                                    <th class="px-4 py-3 text-center text-xs sm:text-sm font-semibold uppercase tracking-wider whitespace-nowrap">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100">
                                @foreach($rejectedApplications as $application)
                                <tr class="searchable-row hover:bg-gray-50 transition-colors duration-150">
                                    <td class="px-4 py-4">
                                        <span class="applicant-id text-[#006633] font-semibold text-sm">{{ $application->user->unique_id ?? $application->user_id }}</span>
                                    </td>
                                    <td class="px-4 py-4">
                                        <span class="applicant-name text-gray-900 font-medium text-sm">{{ $application->first_name }} {{ $application->middle_name }} {{ $application->last_name }}</span>
                                    </td>
                                    <td class="px-4 py-4">
                                        <span class="inline-flex items-center gap-1.5 bg-red-100 text-red-700 px-3 py-1.5 rounded-full text-xs font-semibold">
                                            <i class="fa fa-times"></i>
                                            {{ $application->status }}
                                        </span>
                                    </td>
                                    <td class="px-4 py-4">
                                        <div class="text-sm text-gray-700 max-w-xs truncate" title="{{ $application->remarks }}">{{ $application->remarks }}</div>
                                    </td>
                                    <td class="px-4 py-4">
                                        <div class="flex justify-center">
                                            <button 
                                                type="button" 
                                                class="inline-flex items-center gap-1.5 bg-gradient-to-r from-[#f59e0b] to-[#d97706] text-white px-3 sm:px-4 py-2 rounded-lg text-xs font-semibold hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200"
                                                data-bs-toggle="modal" 
                                                data-bs-target="#unrejectModal-{{ $application->id }}">
                                                <i class="fa fa-undo"></i>
                                                <span class="hidden sm:inline">Unreject</span>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    
                    {{-- Pagination for Rejected --}}
                    <div class="flex flex-col sm:flex-row items-center justify-between gap-4 mt-6">
                        <div class="text-xs md:text-sm text-gray-600 order-1">
                            Showing <span id="rejected-start" class="font-semibold">1</span> to <span id="rejected-end" class="font-semibold">10</span> of <span id="rejected-total" class="font-semibold">{{ $rejectedApplications->count() }}</span> applications
                        </div>
                        <div class="flex items-center gap-1 md:gap-2 order-2">
                            <button type="button" onclick="changePage('rejected', -1)" class="px-2 md:px-3 py-1.5 md:py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm" id="rejected-prev">
                                <i class="fa fa-chevron-left"></i>
                            </button>
                            <div id="rejected-pages" class="flex items-center gap-1"></div>
                            <button type="button" onclick="changePage('rejected', 1)" class="px-2 md:px-3 py-1.5 md:py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm" id="rejected-next">
                                <i class="fa fa-chevron-right"></i>
                            </button>
                        </div>
                    </div>
                    @else
                    <div class="flex flex-col items-center justify-center py-16 text-gray-400">
                        <i class="fa fa-check-circle text-5xl sm:text-6xl mb-4 opacity-30"></i>
                        <p class="text-base sm:text-lg font-medium">No rejected applications</p>
                    </div>
                    @endif
                </div>

            </div>

            {{-- Card Footer --}}
            <div class="bg-gray-50 px-4 sm:px-6 lg:px-8 py-4 flex flex-col sm:flex-row justify-between items-center gap-3 border-t border-[#006633]/12">
                <span class="text-xs sm:text-sm text-gray-500 italic text-center sm:text-left">Sieving for Excellence — Nurturing a Culture of Excellence</span>
                <span class="flex items-center gap-2 text-[#006633] font-bold text-sm">
                    <i class="fa fa-university"></i>
                    CLSU
                </span>
            </div>
        </div>
    </div>
</div>

{{-- ==================== MODALS ==================== --}}

{{-- Accept Modals --}}
@foreach($pendingApplications as $application)
<div class="modal fade" id="acceptModal-{{ $application->id }}" tabindex="-1" aria-labelledby="acceptModalLabel-{{ $application->id }}" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form action="{{ route('admin.application.accept', $application->id) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="modal-content border-0 shadow-2xl rounded-2xl overflow-hidden">
                <div class="bg-gradient-to-r from-[#008844] to-[#006633] px-6 py-4 flex items-center justify-between">
                    <h5 class="text-white font-bold text-lg flex items-center gap-2 m-0">
                        <i class="fa fa-check-circle"></i>
                        Accept Application
                    </h5>
                    <button type="button" class="text-white/80 hover:text-white transition-colors" data-bs-dismiss="modal" aria-label="Close">
                        <i class="fa fa-times text-xl"></i>
                    </button>
                </div>
                <div class="p-6 bg-white">
                    <p class="text-gray-700 mb-4">Are you sure you want to accept this application?</p>
                    <p class="text-gray-900"><strong>Applicant:</strong> {{ $application->first_name }} {{ $application->middle_name }} {{ $application->last_name }}</p>
                </div>
                <div class="bg-gray-50 px-6 py-4 flex gap-3 justify-end">
                    <button type="button" class="px-5 py-2.5 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-lg font-semibold text-sm transition-colors" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="px-5 py-2.5 bg-gradient-to-r from-[#008844] to-[#006633] hover:shadow-lg text-white rounded-lg font-semibold text-sm transition-all flex items-center gap-2">
                        <i class="fa fa-check"></i>
                        Confirm
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

{{-- Reject Modals --}}
<div class="modal fade" id="rejectModal-{{ $application->id }}" tabindex="-1" aria-labelledby="rejectModalLabel-{{ $application->id }}" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        @php
            $routePrefix = match ((int) auth()->user()->role) {
                2 => 'admin',
                3 => 'assessor',
                4 => 'department',
                5 => 'college',
                default => 'admin',
            };
        @endphp
        <form action="{{ route($routePrefix . '.application.reject', $application->id) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="modal-content border-0 shadow-2xl rounded-2xl overflow-hidden">
                <div class="bg-gradient-to-r from-[#ef4444] to-[#dc2626] px-6 py-4 flex items-center justify-between">
                    <h5 class="text-white font-bold text-lg flex items-center gap-2 m-0">
                        <i class="fa fa-times-circle"></i>
                        Reject Application
                    </h5>
                    <button type="button" class="text-white/80 hover:text-white transition-colors" data-bs-dismiss="modal" aria-label="Close">
                        <i class="fa fa-times text-xl"></i>
                    </button>
                </div>
                <div class="p-6 bg-white">
                    <p class="text-gray-900 mb-4"><strong>Applicant:</strong> {{ $application->first_name }} {{ $application->middle_name }} {{ $application->last_name }}</p>
                    <label for="remarks-{{ $application->id }}" class="block text-gray-700 font-semibold mb-2">
                        Please enter remarks for rejection:
                    </label>
                    <textarea 
                        class="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-[#006633] focus:ring-4 focus:ring-[#006633]/10 transition-all" 
                        id="remarks-{{ $application->id }}" 
                        name="remarks" 
                        rows="4" 
                        required 
                        placeholder="Enter reason for rejection..."></textarea>
                </div>
                <div class="bg-gray-50 px-6 py-4 flex gap-3 justify-end">
                    <button type="button" class="px-5 py-2.5 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-lg font-semibold text-sm transition-colors" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="px-5 py-2.5 bg-gradient-to-r from-[#ef4444] to-[#dc2626] hover:shadow-lg text-white rounded-lg font-semibold text-sm transition-all flex items-center gap-2">
                        <i class="fa fa-times"></i>
                        Confirm Reject
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
@endforeach

{{-- Unreject Modals --}}
@foreach($rejectedApplications as $application)
<div class="modal fade" id="unrejectModal-{{ $application->id }}" tabindex="-1" aria-labelledby="unrejectModalLabel-{{ $application->id }}" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form action="{{ route('admin.application.unreject', $application->id) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="modal-content border-0 shadow-2xl rounded-2xl overflow-hidden">
                <div class="bg-gradient-to-r from-[#f59e0b] to-[#d97706] px-6 py-4 flex items-center justify-between">
                    <h5 class="text-white font-bold text-lg flex items-center gap-2 m-0">
                        <i class="fa fa-undo"></i>
                        Confirm Unreject
                    </h5>
                    <button type="button" class="text-white/80 hover:text-white transition-colors" data-bs-dismiss="modal" aria-label="Close">
                        <i class="fa fa-times text-xl"></i>
                    </button>
                </div>
                <div class="p-6 bg-white">
                    <p class="text-gray-700 mb-4">Are you sure you want to unreject this application?</p>
                    <p class="text-gray-900 mb-4"><strong>Applicant:</strong> {{ $application->first_name }} {{ $application->middle_name }} {{ $application->last_name }}</p>
                    <p class="text-gray-900 font-semibold">This action will move the application back to pending status.</p>
                </div>
                <div class="bg-gray-50 px-6 py-4 flex gap-3 justify-end">
                    <button type="button" class="px-5 py-2.5 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-lg font-semibold text-sm transition-colors" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="px-5 py-2.5 bg-gradient-to-r from-[#f59e0b] to-[#d97706] hover:shadow-lg text-white rounded-lg font-semibold text-sm transition-all flex items-center gap-2">
                        <i class="fa fa-undo"></i>
                        Yes, Unreject
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
@endforeach

{{-- Scripts --}}
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    // Track current active tab
    let currentTab = 'pending';
    const ITEMS_PER_PAGE = 10;
    let currentPages = {
        'pending': 1,
        'accepted': 1,
        'rejected': 1
    };
    
    // Tab switching function
    function showTab(tabName) {
        currentTab = tabName;
        
        // Hide all tabs
        document.querySelectorAll('.tab-content').forEach(tab => tab.style.display = 'none');
        
        // Show selected tab
        document.getElementById(tabName).style.display = 'block';
        
        // Update active button
        document.querySelectorAll('.clsu-tab-btn').forEach(btn => btn.classList.remove('active'));
        document.querySelector(`.clsu-tab-btn[data-tab="${tabName}"]`).classList.add('active');
        
        // Update pagination for the new tab
        updatePagination(tabName);
    }
    
    // Search function with pagination reset
    function applySearch() {
        const searchValue = document.getElementById('searchBar').value.toLowerCase().trim();
        const activeTab = document.getElementById(currentTab);
        
        if (!activeTab) return;
        
        const rows = activeTab.querySelectorAll('.searchable-row');
        
        rows.forEach(row => {
            const name = row.querySelector('.applicant-name');
            const id = row.querySelector('.applicant-id');
            
            let nameText = name ? name.textContent.toLowerCase() : '';
            let idText = id ? id.textContent.toLowerCase() : '';
            
            if (searchValue === '' || nameText.includes(searchValue) || idText.includes(searchValue)) {
                row.classList.remove('search-hidden');
            } else {
                row.classList.add('search-hidden');
            }
        });
        
        // Reset to page 1 when searching
        currentPages[currentTab] = 1;
        updatePagination(currentTab);
    }
    
    // Pagination functions
    function updatePagination(tabName) {
        const tab = document.getElementById(tabName);
        if (!tab) return;
        
        const rows = tab.querySelectorAll('.searchable-row');
        const visibleRows = Array.from(rows).filter(row => !row.classList.contains('search-hidden'));
        const totalItems = visibleRows.length;
        const totalPages = Math.ceil(totalItems / ITEMS_PER_PAGE);
        const currentPage = currentPages[tabName];
        
        // Hide all rows first
        visibleRows.forEach(row => row.style.display = 'none');
        
        // Show only rows for current page
        const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
        const endIndex = Math.min(startIndex + ITEMS_PER_PAGE, totalItems);
        
        for (let i = startIndex; i < endIndex; i++) {
            if (visibleRows[i]) {
                visibleRows[i].style.display = '';
            }
        }
        
        // Update pagination info
        const startEl = document.getElementById(`${tabName}-start`);
        const endEl = document.getElementById(`${tabName}-end`);
        const totalEl = document.getElementById(`${tabName}-total`);
        
        if (startEl) startEl.textContent = totalItems > 0 ? startIndex + 1 : 0;
        if (endEl) endEl.textContent = endIndex;
        if (totalEl) totalEl.textContent = totalItems;
        
        // Update page buttons
        const pagesContainer = document.getElementById(`${tabName}-pages`);
        if (pagesContainer) {
            pagesContainer.innerHTML = '';
            
            // Show max 5 page buttons
            let startPage = Math.max(1, currentPage - 2);
            let endPage = Math.min(totalPages, startPage + 4);
            
            if (endPage - startPage < 4) {
                startPage = Math.max(1, endPage - 4);
            }
            
            for (let i = startPage; i <= endPage; i++) {
                const pageBtn = document.createElement('button');
                pageBtn.type = 'button';
                pageBtn.textContent = i;
                pageBtn.className = `px-2 md:px-3 py-1.5 md:py-2 rounded-lg text-xs md:text-sm font-semibold transition-colors ${
                    i === currentPage 
                        ? 'bg-[#006633] text-white' 
                        : 'border border-gray-300 text-gray-700 hover:bg-gray-50'
                }`;
                pageBtn.onclick = () => goToPage(tabName, i);
                pagesContainer.appendChild(pageBtn);
            }
        }
        
        // Update prev/next buttons
        const prevBtn = document.getElementById(`${tabName}-prev`);
        const nextBtn = document.getElementById(`${tabName}-next`);
        
        if (prevBtn) prevBtn.disabled = currentPage <= 1;
        if (nextBtn) nextBtn.disabled = currentPage >= totalPages;
    }
    
    function changePage(tabName, direction) {
        const tab = document.getElementById(tabName);
        if (!tab) return;
        
        const rows = tab.querySelectorAll('.searchable-row');
        const visibleRows = Array.from(rows).filter(row => !row.classList.contains('search-hidden'));
        const totalPages = Math.ceil(visibleRows.length / ITEMS_PER_PAGE);
        
        currentPages[tabName] = Math.max(1, Math.min(totalPages, currentPages[tabName] + direction));
        updatePagination(tabName);
    }
    
    function goToPage(tabName, pageNumber) {
        currentPages[tabName] = pageNumber;
        updatePagination(tabName);
    }
    
    // Attach search event listener
    document.getElementById('searchBar').addEventListener('keyup', applySearch);
    document.getElementById('searchBar').addEventListener('input', applySearch);
    
    // Initialize pagination on page load
    document.addEventListener('DOMContentLoaded', function() {
        updatePagination('pending');
    });
</script>

<style>
/* Tab button styles */
.clsu-tab-btn {
    background: transparent;
    color: #6b7280;
    border: none;
    cursor: pointer;
}

.clsu-tab-btn:hover {
    transform: translateY(-1px);
}

.clsu-tab-pending.active,
.clsu-tab-pending:hover {
    background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
    color: white;
    box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
}

.clsu-tab-accepted.active,
.clsu-tab-accepted:hover {
    background: linear-gradient(135deg, #008844 0%, #006633 100%);
    color: white;
    box-shadow: 0 4px 12px rgba(0, 102, 51, 0.3);
}

.clsu-tab-rejected.active,
.clsu-tab-rejected:hover {
    background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
    color: white;
    box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
}

/* Responsive text visibility */
@media (min-width: 400px) {
    .xs\:inline {
        display: inline;
    }
}
</style>

@endsection

@section('scripts')
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
@endsection