@extends('layouts.admin')

@section('content')
{{-- Tailwind CSS CDN --}}
<script src="https://cdn.tailwindcss.com"></script>
<script>
    tailwind.config = {
        theme: {
            extend: {
                colors: {
                    'clsu-green': '#087a29',
                    'clsu-green-dark': '#065a1f',
                    'clsu-green-light': '#0a9432',
                    'clsu-yellow': '#F9B233',
                    'clsu-gold': '#D4AF37',
                }
            }
        }
    }
</script>

<style>
    @import url('https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@300;400;500;600;700;800&family=Playfair+Display:wght@500;600;700&display=swap');
    
    .font-franklin { font-family: 'Libre Franklin', sans-serif; }
    .font-playfair { font-family: 'Playfair Display', serif; }

    /* Application row visibility for pagination */
    .application-row {
        display: none;
    }

    .application-row.active {
        display: table-row;
    }

    /* Custom Pagination Styling */
    .pagination-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 1rem;
        flex-wrap: wrap;
    }

    .pagination-wrapper {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 0.5rem;
        flex-wrap: wrap;
    }

    .pagination-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 2.25rem;
        height: 2.25rem;
        padding: 0;
        border-radius: 0.375rem;
        font-size: 0.875rem;
        font-weight: 500;
        transition: all 0.2s;
        border: 1px solid #d1d5db;
        background: white;
        color: #6b7280;
        text-decoration: none;
        cursor: pointer;
    }

    .pagination-btn:hover:not(.disabled):not(.active) {
        background: #f9fafb;
        border-color: #9ca3af;
        color: #374151;
    }

    .pagination-btn.active {
        background: #087a29;
        color: white;
        border-color: #087a29;
    }

    .pagination-btn.disabled {
        opacity: 0.5;
        cursor: not-allowed;
        pointer-events: none;
        background: #f9fafb;
    }

    .pagination-dots {
        color: #6b7280;
        font-weight: normal;
        padding: 0 0.25rem;
    }

    /* Mobile responsive table */
    @media (max-width: 768px) {
        .responsive-table {
            display: block;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .responsive-table table {
            min-width: 640px;
        }
    }

    /* Custom Green Scrollbar */
    .responsive-table::-webkit-scrollbar {
        height: 12px;
        width: 12px;
    }

    .responsive-table::-webkit-scrollbar-track {
        background: #f0fdf4;
        border-radius: 10px;
    }

    .responsive-table::-webkit-scrollbar-thumb {
        background: linear-gradient(180deg, #087a29 0%, #065a1f 100%);
        border-radius: 10px;
        border: 2px solid #f0fdf4;
        cursor: pointer;
    }

    .responsive-table::-webkit-scrollbar-thumb:hover {
        background: linear-gradient(180deg, #0a9432 0%, #087a29 100%);
    }

    .responsive-table::-webkit-scrollbar-thumb:active {
        background: #065a1f;
    }

    /* Firefox scrollbar */
    .responsive-table {
        scrollbar-width: thin;
        scrollbar-color: #087a29 #f0fdf4;
    }

    /* Make scrollbar more prominent on mobile */
    @media (max-width: 768px) {
        .responsive-table::-webkit-scrollbar {
            height: 14px;
        }

        .responsive-table::-webkit-scrollbar-thumb {
            border: 3px solid #f0fdf4;
        }
    }
</style>

<div class="min-h-screen bg-gradient-to-br from-green-50 via-white to-yellow-50 p-3 sm:p-4 md:p-6 font-franklin">
    <div class="max-w-7xl mx-auto">
        
        {{-- Header Card --}}
        <div class="bg-white rounded-xl sm:rounded-2xl shadow-lg overflow-hidden mb-4 sm:mb-6 border border-green-100">
            {{-- Green Header --}}
            <div class="bg-gradient-to-r from-clsu-green to-clsu-green-dark p-4 sm:p-5 md:p-6 relative overflow-hidden">
                {{-- Decorative circles --}}
                <div class="absolute top-0 right-0 w-32 sm:w-40 h-32 sm:h-40 bg-clsu-yellow/10 rounded-full -translate-y-1/2 translate-x-1/2"></div>
                <div class="absolute bottom-0 left-1/4 w-16 sm:w-20 h-16 sm:h-20 bg-white/5 rounded-full translate-y-1/2"></div>
                
                <div class="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-3 sm:gap-4">
                    <div>
                        <div class="flex items-start sm:items-center gap-2 sm:gap-3 mb-2">
                            <div>
                                <h1 class="text-lg sm:text-xl md:text-2xl lg:text-3xl font-playfair font-bold text-white leading-tight">Department Coordinator Dashboard</h1>
                                <p class="text-green-100 text-xs sm:text-sm mt-1">Review applications from assessors</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                {{-- Gold accent line --}}
                <div class="absolute bottom-0 left-0 right-0 h-0.5 sm:h-1 bg-gradient-to-r from-clsu-yellow via-clsu-gold to-clsu-yellow"></div>
            </div>
            
            {{-- Alert Messages --}}
            @if(session('success'))
            <div class="mx-3 sm:mx-4 md:mx-6 mt-3 sm:mt-4 p-3 sm:p-4 bg-green-50 border-l-4 border-clsu-green rounded-r-lg flex items-start gap-2 sm:gap-3">
                <div class="w-7 h-7 sm:w-8 sm:h-8 bg-clsu-green rounded-full flex items-center justify-center flex-shrink-0">
                    <i class="fa fa-check text-white text-xs sm:text-sm"></i>
                </div>
                <p class="text-clsu-green-dark font-medium text-xs sm:text-sm">{{ session('success') }}</p>
            </div>
            @endif
            
            @if(session('error'))
            <div class="mx-3 sm:mx-4 md:mx-6 mt-3 sm:mt-4 p-3 sm:p-4 bg-red-50 border-l-4 border-red-500 rounded-r-lg flex items-start gap-2 sm:gap-3">
                <div class="w-7 h-7 sm:w-8 sm:h-8 bg-red-500 rounded-full flex items-center justify-center flex-shrink-0">
                    <i class="fa fa-times text-white text-xs sm:text-sm"></i>
                </div>
                <p class="text-red-700 font-medium text-xs sm:text-sm">{{ session('error') }}</p>
            </div>
            @endif
            
            {{-- Table Section --}}
            <div class="p-3 sm:p-4 md:p-6">
                @if(count($applications) > 0)
                <div class="responsive-table">
                    <table class="w-full" id="applicationsTable">
                        <thead>
                            <tr class="bg-gradient-to-r from-gray-50 to-gray-100">
                                <th class="px-3 sm:px-4 py-3 sm:py-4 text-left text-[10px] sm:text-xs font-bold text-gray-600 uppercase tracking-wider rounded-tl-xl">Applicant Name</th>
                                <th class="px-3 sm:px-4 py-3 sm:py-4 text-left text-[10px] sm:text-xs font-bold text-gray-600 uppercase tracking-wider">Status</th>
                                <th class="px-3 sm:px-4 py-3 sm:py-4 text-center text-[10px] sm:text-xs font-bold text-gray-600 uppercase tracking-wider rounded-tr-xl">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            @foreach($applications as $index => $application)
                            <tr class="application-row hover:bg-green-50/50 transition-colors duration-200" data-index="{{ $index }}">
                                {{-- Name --}}
                                <td class="px-3 sm:px-4 py-3 sm:py-4">
                                    <div class="flex items-center gap-2 sm:gap-3">
                                        <div class="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-gradient-to-br from-clsu-green to-clsu-green-dark flex items-center justify-center text-white font-bold text-xs sm:text-sm flex-shrink-0">
                                            {{ strtoupper(substr($application->first_name, 0, 1)) }}{{ strtoupper(substr($application->last_name, 0, 1)) }}
                                        </div>
                                        <div class="min-w-0">
                                            <p class="font-semibold text-gray-800 text-xs sm:text-sm applicant-name truncate">{{ $application->first_name }} {{ $application->middle_name }} {{ $application->last_name }}</p>
                                            <p class="text-xs text-gray-500">
                                                <span class="applicant-id">#{{ $application->user->unique_id ?? $application->user_id }}</span>
                                            </p>
                                        </div>
                                    </div>
                                </td>
                                
                                {{-- Status --}}
                                <td class="px-3 sm:px-4 py-3 sm:py-4">
                                    @if($application->status == 'Accepted by Assessor')
                                    <span class="inline-flex items-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-1 sm:py-1.5 rounded-full text-[10px] sm:text-xs font-semibold bg-teal-100 text-teal-700 whitespace-nowrap">
                                        <span class="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-teal-500 animate-pulse"></span>
                                        <span class="hidden sm:inline">{{ $application->status }}</span>
                                        <span class="sm:hidden">Pending</span>
                                    </span>
                                    @elseif($application->status == 'Accepted by Department Coordinator')
                                    <span class="inline-flex items-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-1 sm:py-1.5 rounded-full text-[10px] sm:text-xs font-semibold bg-green-100 text-green-700 whitespace-nowrap">
                                        <i class="fa fa-check-circle text-[10px] sm:text-xs"></i>
                                        <span class="hidden sm:inline">{{ $application->status }}</span>
                                        <span class="sm:hidden">Accepted</span>
                                    </span>
                                    @elseif(str_contains($application->status, 'Accepted'))
                                    <span class="inline-flex items-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-1 sm:py-1.5 rounded-full text-[10px] sm:text-xs font-semibold bg-green-100 text-green-700 whitespace-nowrap">
                                        <i class="fa fa-check-circle text-[10px] sm:text-xs"></i>
                                        <span class="hidden sm:inline">{{ $application->status }}</span>
                                        <span class="sm:hidden">Accepted</span>
                                    </span>
                                    @elseif(str_contains($application->status, 'Rejected'))
                                    <span class="inline-flex items-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-1 sm:py-1.5 rounded-full text-[10px] sm:text-xs font-semibold bg-red-100 text-red-700 whitespace-nowrap">
                                        <i class="fa fa-times-circle text-[10px] sm:text-xs"></i>
                                        <span class="hidden sm:inline">{{ $application->status }}</span>
                                        <span class="sm:hidden">Rejected</span>
                                    </span>
                                    @else
                                    <span class="inline-flex items-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-1 sm:py-1.5 rounded-full text-[10px] sm:text-xs font-semibold bg-gray-100 text-gray-700 whitespace-nowrap">
                                        <span class="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-gray-400"></span>
                                        {{ $application->status }}
                                    </span>
                                    @endif
                                </td>
                                
                                {{-- Actions --}}
                                <td class="px-3 sm:px-4 py-3 sm:py-4">
                                    <div class="flex items-center justify-center gap-1.5 sm:gap-2">
                                        @if($application->status == 'Accepted by Assessor')
                                        {{-- Accept Button --}}
                                        <button 
                                            class="px-2.5 sm:px-4 py-1.5 sm:py-2 rounded-lg text-[10px] sm:text-xs font-semibold bg-gradient-to-r from-clsu-green to-clsu-green-dark text-white hover:from-clsu-green-dark hover:to-clsu-green transition-all shadow-sm hover:shadow-md flex items-center gap-1 sm:gap-1.5 whitespace-nowrap"
                                            data-bs-toggle="modal" 
                                            data-bs-target="#acceptModal-{{ $application->id }}">
                                            <i class="fa fa-check text-[9px] sm:text-xs"></i>
                                            <span class="hidden sm:inline">Accept</span>
                                        </button>
                                        
                                        {{-- Reject Button --}}
                                        <button 
                                            class="px-2.5 sm:px-4 py-1.5 sm:py-2 rounded-lg text-[10px] sm:text-xs font-semibold bg-gradient-to-r from-red-500 to-red-600 text-white hover:from-red-600 hover:to-red-700 transition-all shadow-sm hover:shadow-md flex items-center gap-1 sm:gap-1.5 whitespace-nowrap"
                                            data-bs-toggle="modal" 
                                            data-bs-target="#rejectModal-{{ $application->id }}">
                                            <i class="fa fa-times text-[9px] sm:text-xs"></i>
                                            <span class="hidden sm:inline">Reject</span>
                                        </button>
                                        @else
                                        {{-- View Button --}}
                                        <a href="{{ route('department.application.show', $application->id) }}" 
                                           class="px-2.5 sm:px-4 py-1.5 sm:py-2 rounded-lg text-[10px] sm:text-xs font-semibold bg-gradient-to-r from-blue-500 to-blue-600 text-white hover:from-blue-600 hover:to-blue-700 transition-all shadow-sm hover:shadow-md inline-flex items-center gap-1 sm:gap-1.5 no-underline whitespace-nowrap">
                                            <i class="fa fa-eye text-[9px] sm:text-xs"></i>
                                            <span>View</span>
                                        </a>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                {{-- Pagination Controls --}}
                <div id="paginationControls" class="border-t border-gray-200 pt-3 sm:pt-4 md:pt-5 mt-3 sm:mt-4 md:mt-5">
                    <div class="pagination-container">
                        {{-- Page Info on the left --}}
                        <div class="text-[11px] sm:text-xs md:text-sm text-gray-600 w-full sm:w-auto text-center sm:text-left" id="pageInfo">
                            <!-- Page info will be inserted here by JavaScript -->
                        </div>

                        {{-- Pagination buttons on the right --}}
                        <div class="pagination-wrapper w-full sm:w-auto justify-center sm:justify-end" id="paginationWrapper">
                            <!-- Pagination buttons will be inserted here by JavaScript -->
                        </div>
                    </div>
                </div>
                @else
                <div class="text-center py-10 sm:py-16">
                    <div class="w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 bg-gradient-to-br from-green-50 to-green-100 rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6">
                        <i class="fa fa-inbox text-3xl sm:text-4xl md:text-5xl text-clsu-green opacity-50"></i>
                    </div>
                    <h3 class="text-base sm:text-lg md:text-xl font-bold text-gray-800 mb-2">No Applications Found</h3>
                    <p class="text-xs sm:text-sm md:text-base text-gray-500">Applications from assessors will appear here.</p>
                </div>
                @endif
            </div>
            
            {{-- Footer --}}
            <div class="bg-gradient-to-r from-clsu-green to-clsu-green-dark px-4 sm:px-5 md:px-6 py-2.5 sm:py-3 flex flex-col sm:flex-row justify-between items-center gap-1.5 sm:gap-2 text-[10px] sm:text-xs italic">
                <p class="text-green-100 text-center sm:text-left">Sieving for Excellence</p>
                <p class="text-clsu-yellow font-semibold flex items-center gap-1.5 sm:gap-2">
                    <i class="fa fa-university"></i>
                    CLSU ETEEAP
                </p>
            </div>
        </div>
        
    </div>
</div>

{{-- ==================== MODALS ==================== --}}
@foreach($applications as $application)
@if($application->status == 'Accepted by Assessor')

{{-- Accept Modal --}}
<div class="modal fade" id="acceptModal-{{ $application->id }}" tabindex="-1" aria-labelledby="acceptModalLabel-{{ $application->id }}" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form action="{{ route('department.application.accept', $application->id) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="modal-content border-0 rounded-2xl overflow-hidden shadow-2xl">
                {{-- Header --}}
                <div class="bg-gradient-to-r from-clsu-green to-clsu-green-dark p-5 relative">
                    <div class="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-clsu-yellow via-clsu-gold to-clsu-yellow"></div>
                    <div class="flex items-center gap-3">
                        <div class="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
                            <i class="fa fa-check-circle text-clsu-yellow text-xl"></i>
                        </div>
                        <div>
                            <h5 class="text-xl font-playfair font-bold text-white mb-0">Accept Application</h5>
                            <p class="text-green-100 text-sm mb-0">Forward to College Coordinator</p>
                        </div>
                    </div>
                    <button type="button" class="absolute top-4 right-4 text-white/70 hover:text-white transition-colors" data-bs-dismiss="modal" aria-label="Close">
                        <i class="fa fa-times text-xl"></i>
                    </button>
                </div>
                
                {{-- Body --}}
                <div class="p-6 bg-white">
                    <p class="text-gray-600 mb-4">Are you sure you want to <strong class="text-clsu-green">accept</strong> this application?</p>
                    
                    <div class="bg-green-50 rounded-xl p-4 border-l-4 border-clsu-green">
                        <p class="text-xs text-gray-500 mb-1">Applicant</p>
                        <p class="font-semibold text-gray-800">{{ $application->first_name }} {{ $application->middle_name }} {{ $application->last_name }}</p>
                    </div>
                    
                    <div class="mt-4 p-3 bg-blue-50 rounded-lg flex items-start gap-2">
                        <i class="fa fa-info-circle text-blue-500 mt-0.5"></i>
                        <p class="text-xs text-blue-700">This application will be forwarded to the College Coordinator for final review.</p>
                    </div>
                </div>
                
                {{-- Footer --}}
                <div class="px-6 py-4 bg-gray-50 flex justify-end gap-3">
                    <button type="button" class="px-5 py-2.5 rounded-xl font-semibold text-gray-600 bg-gray-200 hover:bg-gray-300 transition-colors" data-bs-dismiss="modal">
                        Cancel
                    </button>
                    <button type="submit" class="px-5 py-2.5 rounded-xl font-semibold text-white bg-gradient-to-r from-clsu-green to-clsu-green-dark hover:from-clsu-green-dark hover:to-clsu-green transition-all shadow-md hover:shadow-lg">
                        <i class="fa fa-check mr-1"></i> Confirm Accept
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

{{-- Reject Modal --}}
<div class="modal fade" id="rejectModal-{{ $application->id }}" tabindex="-1" aria-labelledby="rejectModalLabel-{{ $application->id }}" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form action="{{ route('department.application.reject', $application->id) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="modal-content border-0 rounded-2xl overflow-hidden shadow-2xl">
                {{-- Header --}}
                <div class="bg-gradient-to-r from-red-500 to-red-600 p-5 relative">
                    <div class="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-red-300 via-red-200 to-red-300"></div>
                    <div class="flex items-center gap-3">
                        <div class="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
                            <i class="fa fa-times-circle text-red-200 text-xl"></i>
                        </div>
                        <div>
                            <h5 class="text-xl font-playfair font-bold text-white mb-0">Reject Application</h5>
                            <p class="text-red-100 text-sm mb-0">Please provide a reason</p>
                        </div>
                    </div>
                    <button type="button" class="absolute top-4 right-4 text-white/70 hover:text-white transition-colors" data-bs-dismiss="modal" aria-label="Close">
                        <i class="fa fa-times text-xl"></i>
                    </button>
                </div>
                
                {{-- Body --}}
                <div class="p-6 bg-white">
                    <div class="bg-red-50 rounded-xl p-4 border-l-4 border-red-500 mb-4">
                        <p class="text-xs text-gray-500 mb-1">Applicant</p>
                        <p class="font-semibold text-gray-800">{{ $application->first_name }} {{ $application->middle_name }} {{ $application->last_name }}</p>
                    </div>
                    
                    <div class="mb-2">
                        <label for="remarks-{{ $application->id }}" class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="fa fa-comment text-red-500 mr-1"></i>
                            Rejection Remarks <span class="text-red-500">*</span>
                        </label>
                        <textarea 
                            class="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-red-400 focus:ring focus:ring-red-100 transition-all resize-none" 
                            id="remarks-{{ $application->id }}" 
                            name="remarks" 
                            rows="4"
                            placeholder="Please explain the reason for rejection..."
                            required></textarea>
                    </div>
                </div>
                
                {{-- Footer --}}
                <div class="px-6 py-4 bg-gray-50 flex justify-end gap-3">
                    <button type="button" class="px-5 py-2.5 rounded-xl font-semibold text-gray-600 bg-gray-200 hover:bg-gray-300 transition-colors" data-bs-dismiss="modal">
                        Cancel
                    </button>
                    <button type="submit" class="px-5 py-2.5 rounded-xl font-semibold text-white bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 transition-all shadow-md hover:shadow-lg">
                        <i class="fa fa-times mr-1"></i> Confirm Reject
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

@endif
@endforeach

{{-- Client-Side Pagination Script --}}
<script>
document.addEventListener('DOMContentLoaded', function() {
    const itemsPerPage = 10;
    let currentPage = 1;
    const rows = document.querySelectorAll('.application-row');
    const totalItems = rows.length;
    const totalPages = Math.ceil(totalItems / itemsPerPage);

    function showPage(page) {
        // Hide all rows
        rows.forEach(row => {
            row.classList.remove('active');
        });

        // Calculate start and end index
        const start = (page - 1) * itemsPerPage;
        const end = start + itemsPerPage;

        // Show rows for current page
        for (let i = start; i < end && i < totalItems; i++) {
            rows[i].classList.add('active');
        }

        // Update pagination controls
        updatePagination(page);
        
        // Update page info
        updatePageInfo(page, start, end);
    }

    function updatePagination(page) {
        const wrapper = document.getElementById('paginationWrapper');
        if (!wrapper) return;

        let html = '';

        // Previous button
        if (page === 1) {
            html += '<button class="pagination-btn disabled"><i class="fa fa-chevron-left"></i></button>';
        } else {
            html += `<button class="pagination-btn" onclick="goToPage(${page - 1})"><i class="fa fa-chevron-left"></i></button>`;
        }

        // Page numbers
        let start = Math.max(1, page - 1);
        let end = Math.min(totalPages, page + 1);

        if (start > 1) {
            html += `<button class="pagination-btn" onclick="goToPage(1)">1</button>`;
            if (start > 2) {
                html += '<span class="pagination-dots">•••</span>';
            }
        }

        for (let i = start; i <= end; i++) {
            if (i === page) {
                html += `<button class="pagination-btn active">${i}</button>`;
            } else {
                html += `<button class="pagination-btn" onclick="goToPage(${i})">${i}</button>`;
            }
        }

        if (end < totalPages) {
            if (end < totalPages - 1) {
                html += '<span class="pagination-dots">•••</span>';
            }
            html += `<button class="pagination-btn" onclick="goToPage(${totalPages})">${totalPages}</button>`;
        }

        // Next button
        if (page === totalPages) {
            html += '<button class="pagination-btn disabled"><i class="fa fa-chevron-right"></i></button>';
        } else {
            html += `<button class="pagination-btn" onclick="goToPage(${page + 1})"><i class="fa fa-chevron-right"></i></button>`;
        }

        wrapper.innerHTML = html;
    }

    function updatePageInfo(page, start, end) {
        const pageInfo = document.getElementById('pageInfo');
        if (!pageInfo) return;

        const actualEnd = Math.min(end, totalItems);
        pageInfo.textContent = `Showing ${start + 1} to ${actualEnd} of ${totalItems} applicants`;
    }

    // Make goToPage function global
    window.goToPage = function(page) {
        currentPage = page;
        showPage(page);
        
        // Scroll to top of table
        const tableElement = document.getElementById('applicationsTable');
        if (tableElement) {
            tableElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    };

    // Initialize pagination if there are rows
    if (totalItems > 0) {
        showPage(1);
    }
});
</script>

@endsection

@section('scripts')
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
@endsection