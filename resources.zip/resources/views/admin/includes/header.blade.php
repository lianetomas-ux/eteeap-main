@php
    $userInitial = strtoupper(substr(Auth::user()->name, 0, 1));
@endphp

<style>
@import url('https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap');

body {
    font-family: 'Libre Franklin', -apple-system, BlinkMacSystemFont, sans-serif;
}
</style>

<!-- Header Navigation -->
<nav class="sticky top-0 z-[55] bg-gradient-to-r from-[#006633] to-[#004d26] shadow-lg shadow-[#006633]/30">
    <!-- Gold accent border -->
    <div class="absolute bottom-0 left-0 right-0 h-[3px] bg-gradient-to-r from-[#FFD700] via-[#D4AF37] to-[#FFD700]"></div>
    
    <div class="max-w-full mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-16">
            
            <!-- Left: Burger Menu (Mobile) + Brand -->
            <div class="flex items-center gap-4">
                <!-- Burger Menu Button (visible on mobile/tablet) -->
                <button 
                    type="button" 
                    id="mobile-menu-button"
                    class="lg:hidden inline-flex items-center justify-center p-2 rounded-lg text-white/90 hover:text-white hover:bg-white/10 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-[#FFD700] transition-all duration-200"
                    aria-controls="mobile-sidebar"
                    aria-expanded="false">
                    <span class="sr-only">Open sidebar</span>
                    <!-- Hamburger Icon -->
                    <svg id="menu-open-icon" class="block h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                    <!-- Close Icon (hidden by default) -->
                    <svg id="menu-close-icon" class="hidden h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>

                <!-- Brand -->
                <a href="{{ route('admin.home') }}" class="flex items-center gap-3 group transition-transform duration-300 hover:translate-x-1">
                    <div class="hidden sm:flex flex-col">
                        <span class="text-white font-bold text-lg leading-tight" style="font-family: 'Playfair Display', serif;">Admin Panel</span>
                        <span class="text-white/75 text-[0.7rem] font-medium uppercase tracking-wider">Central Luzon State University</span>
                    </div>
                </a>
            </div>

            <!-- Right: User Welcome Badge -->
            <div class="flex items-center">
                <div class="flex items-center gap-3 bg-white/10 backdrop-blur-sm px-3 sm:px-4 py-2 rounded-full border border-white/15 hover:bg-white/15 hover:border-white/25 transition-all duration-300">
                    <!-- Avatar -->
                    <div class="flex-shrink-0 w-9 h-9 bg-gradient-to-br from-[#D4AF37] to-[#FFD700] rounded-full flex items-center justify-center font-bold text-sm text-[#004d26] shadow-md">
                        {{ $userInitial }}
                    </div>
                    
                    <!-- Welcome Text (hidden on mobile) -->
                    <div class="hidden sm:flex flex-col">
                        <span class="text-white/70 text-[0.65rem] font-medium uppercase tracking-wide">Welcome back</span>
                        <span class="text-white text-sm font-semibold leading-tight">{{ Auth::user()->name }}</span>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</nav>

<!-- Mobile Menu Toggle Script -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const menuButton = document.getElementById('mobile-menu-button');
    const sidebar = document.getElementById('mobile-sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    const openIcon = document.getElementById('menu-open-icon');
    const closeIcon = document.getElementById('menu-close-icon');
    
    function toggleSidebar() {
        const isOpen = sidebar.classList.contains('translate-x-0');
        
        if (isOpen) {
            // Close sidebar
            sidebar.classList.remove('translate-x-0');
            sidebar.classList.add('-translate-x-full');
            overlay.classList.add('opacity-0');
            setTimeout(() => {
                overlay.classList.add('hidden');
            }, 300);
            menuButton.setAttribute('aria-expanded', 'false');
            openIcon.classList.remove('hidden');
            closeIcon.classList.add('hidden');
            document.body.classList.remove('overflow-hidden');
        } else {
            // Open sidebar
            overlay.classList.remove('hidden');
            setTimeout(() => {
                overlay.classList.remove('opacity-0');
            }, 10);
            sidebar.classList.remove('-translate-x-full');
            sidebar.classList.add('translate-x-0');
            menuButton.setAttribute('aria-expanded', 'true');
            openIcon.classList.add('hidden');
            closeIcon.classList.remove('hidden');
            document.body.classList.add('overflow-hidden', 'lg:overflow-auto');
        }
    }
    
    menuButton.addEventListener('click', toggleSidebar);
    overlay.addEventListener('click', toggleSidebar);
    
    // Close sidebar when window is resized to desktop
    window.addEventListener('resize', function() {
        if (window.innerWidth >= 1024) {
            sidebar.classList.remove('-translate-x-full');
            sidebar.classList.add('translate-x-0');
            overlay.classList.add('hidden');
            document.body.classList.remove('overflow-hidden');
        }
    });
});
</script>

{{-- ================= SWEETALERT2 TOAST ================= --}}
@if(session('success'))
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'success',
        title: {!! json_encode(session('success')) !!},
        showConfirmButton: false,
        timer: 5000,
        timerProgressBar: true,
        background: 'linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%)',
        color: '#166534',
        iconColor: '#006633',
        customClass: {
            popup: 'clsu-toast-popup',
            title: 'clsu-toast-title',
            timerProgressBar: 'clsu-toast-progress'
        },
        didOpen: (toast) => {
            toast.style.borderLeft = '4px solid #006633';
            toast.style.borderRadius = '12px';
            toast.style.boxShadow = '0 10px 40px rgba(0, 102, 51, 0.2)';
            toast.style.padding = '1rem 1.25rem';
            toast.style.fontFamily = "'Libre Franklin', sans-serif";
        }
    });
</script>
<style>
    .clsu-toast-popup {
        font-family: 'Libre Franklin', -apple-system, BlinkMacSystemFont, sans-serif !important;
    }
    .clsu-toast-title {
        font-weight: 600 !important;
        font-size: 0.9rem !important;
    }
    .clsu-toast-progress {
        background: linear-gradient(90deg, #006633 0%, #008844 100%) !important;
    }
    .swal2-icon.swal2-success {
        border-color: #006633 !important;
        color: #006633 !important;
    }
    .swal2-icon.swal2-success .swal2-success-ring {
        border-color: rgba(0, 102, 51, 0.3) !important;
    }
    .swal2-icon.swal2-success [class^='swal2-success-line'] {
        background-color: #006633 !important;
    }
</style>
@endif

@if(session('error'))
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'error',
        title: {!! json_encode(session('error')) !!},
        showConfirmButton: false,
        timer: 5000,
        timerProgressBar: true,
        background: 'linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%)',
        color: '#991b1b',
        iconColor: '#dc2626',
        customClass: {
            popup: 'clsu-toast-popup',
            title: 'clsu-toast-title',
            timerProgressBar: 'clsu-toast-progress-error'
        },
        didOpen: (toast) => {
            toast.style.borderLeft = '4px solid #dc2626';
            toast.style.borderRadius = '12px';
            toast.style.boxShadow = '0 10px 40px rgba(220, 38, 38, 0.2)';
            toast.style.padding = '1rem 1.25rem';
            toast.style.fontFamily = "'Libre Franklin', sans-serif";
        }
    });
</script>
<style>
    .clsu-toast-progress-error {
        background: linear-gradient(90deg, #dc2626 0%, #ef4444 100%) !important;
    }
</style>
@endif