@php
    $userInitial = strtoupper(substr(Auth::user()->name, 0, 1));
    $userRole = Auth::user()->role;
    
    $roleLabel = match($userRole) {
        2 => 'Administrator',
        3 => 'Assessor',
        4 => 'Dept. Coordinator',
        5 => 'College Coordinator',
        default => 'User'
    };
@endphp

<style>
@import url('https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap');

/* Custom scrollbar */
.sidebar-scroll::-webkit-scrollbar {
    width: 6px;
}
.sidebar-scroll::-webkit-scrollbar-track {
    background: rgba(0, 0, 0, 0.1);
}
.sidebar-scroll::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.2);
    border-radius: 10px;
}
.sidebar-scroll::-webkit-scrollbar-thumb:hover {
    background: rgba(255, 255, 255, 0.3);
}
</style>

<!-- Sidebar Overlay (Mobile) -->
<div id="sidebar-overlay" class="hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-[60] lg:hidden transition-opacity duration-300"></div>

<!-- Sidebar -->
<aside 
    id="mobile-sidebar"
    class="fixed lg:static inset-y-0 left-0 z-[70] w-72 bg-gradient-to-b from-[#006633] to-[#004d26] transform -translate-x-full lg:translate-x-0 transition-transform duration-300 ease-in-out shadow-2xl shadow-[#004d26]/30 sidebar-scroll overflow-y-auto"
    role="navigation">
    
    <!-- Decorative Background Gradients -->
    <div class="absolute inset-0 pointer-events-none">
        <div class="absolute top-0 left-0 right-0 h-1/3 bg-gradient-radial from-[#FFD700]/5 via-transparent to-transparent"></div>
        <div class="absolute bottom-0 left-0 w-1/2 h-1/3 bg-gradient-radial from-[#008844]/20 via-transparent to-transparent"></div>
    </div>

    <!-- Sidebar Content -->
    <div class="relative flex flex-col h-full">
        
        {{-- Header / Profile Section --}}
        <div class="relative bg-gradient-to-br from-[#004d26]/50 to-[#006633]/30 px-5 py-7 text-center border-b-[3px] border-[#D4AF37]">
            <!-- Decorative Glow -->
            <div class="absolute inset-0 bg-gradient-radial from-[#FFD700]/10 via-transparent to-transparent pointer-events-none"></div>
            
            <!-- Close Button (Mobile Only) -->
            <button 
                type="button" 
                id="sidebar-close-button"
                class="lg:hidden absolute top-4 right-4 w-9 h-9 flex items-center justify-center rounded-lg bg-white/10 hover:bg-white/20 border border-white/20 hover:border-white/30 text-white/80 hover:text-white transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#FFD700]/50 group z-10"
                aria-label="Close sidebar">
                <svg class="w-5 h-5 group-hover:rotate-90 transition-transform duration-200" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
            
            <!-- Logo -->
            <div class="relative inline-block mb-4">
                <div class="relative">
                    <img src="{{ asset('images/cl.png') }}"
                         alt="CLSU Logo"
                         class="w-20 h-20 rounded-full border-4 border-[#D4AF37] p-1 bg-white shadow-xl shadow-black/30 transition-transform duration-300 hover:scale-105 object-cover">
                    
                    <!-- Badge -->
                    <div class="absolute bottom-0 right-0 w-6 h-6 bg-gradient-to-br from-[#FFD700] to-[#D4AF37] rounded-full flex items-center justify-center border-2 border-[#004d26] shadow-lg">
                        <i class="fa fa-check text-[0.65rem] text-[#004d26]"></i>
                    </div>
                </div>
            </div>
            
            <!-- User Info -->
            <div class="relative z-10">
                <h3 class="text-white font-bold text-base mb-1 drop-shadow-md">{{ Auth::user()->name }}</h3>
                <span class="inline-block bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#004d26] text-[0.65rem] font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                    {{ $roleLabel }}
                </span>
            </div>
        </div>

        {{-- Navigation Menu --}}
        <nav class="flex-1 py-4 px-3 overflow-y-auto">
            
            {{-- Main Section --}}
            <div class="mb-2">
                <h4 class="px-4 text-white/40 text-[0.65rem] font-bold uppercase tracking-widest mb-2">Main</h4>
                
                @if($userRole == 2)
                    <a href="{{ route('admin.home') }}" 
                       class="flex items-center gap-3 px-4 py-3 text-white/85 rounded-lg transition-all duration-200 group {{ request()->routeIs('admin.home') ? 'bg-white/15 shadow-lg border-l-4 border-[#D4AF37]' : 'hover:bg-white/10 hover:translate-x-1' }}">
                        <i class="fas fa-gauge w-5 text-center {{ request()->routeIs('admin.home') ? 'text-[#FFD700] drop-shadow-glow' : 'text-[#D4AF37] group-hover:scale-110' }} transition-all duration-200"></i>
                        <span class="flex-1 font-medium text-sm">Dashboard</span>
                    </a>

                @elseif($userRole == 3)
                    <a href="{{ route('assessor.dashboard') }}" 
                       class="flex items-center gap-3 px-4 py-3 text-white/85 rounded-lg transition-all duration-200 group {{ request()->routeIs('assessor.dashboard') ? 'bg-white/15 shadow-lg border-l-4 border-[#D4AF37]' : 'hover:bg-white/10 hover:translate-x-1' }}">
                        <i class="fa fa-check-circle w-5 text-center {{ request()->routeIs('assessor.dashboard') ? 'text-[#FFD700] drop-shadow-glow' : 'text-[#D4AF37] group-hover:scale-110' }} transition-all duration-200"></i>
                        <span class="flex-1 font-medium text-sm">Assessor Dashboard</span>
                    </a>
                    <a href="{{ route('admin.accepted.applicants') }}" 
                       class="flex items-center gap-3 px-4 py-3 text-white/85 rounded-lg transition-all duration-200 group {{ request()->routeIs('admin.accepted.applicants*') ? 'bg-white/15 shadow-lg border-l-4 border-[#D4AF37]' : 'hover:bg-white/10 hover:translate-x-1' }}">
                        <i class="fa fa-users w-5 text-center {{ request()->routeIs('admin.accepted.applicants*') ? 'text-[#FFD700] drop-shadow-glow' : 'text-[#D4AF37] group-hover:scale-110' }} transition-all duration-200"></i>
                        <span class="flex-1 font-medium text-sm">Accepted Applicants</span>
                    </a>

                @elseif($userRole == 4)
                    <a href="{{ route('department.dashboard') }}" 
                       class="flex items-center gap-3 px-4 py-3 text-white/85 rounded-lg transition-all duration-200 group {{ request()->routeIs('department.dashboard') ? 'bg-white/15 shadow-lg border-l-4 border-[#D4AF37]' : 'hover:bg-white/10 hover:translate-x-1' }}">
                        <i class="fa fa-building w-5 text-center {{ request()->routeIs('department.dashboard') ? 'text-[#FFD700] drop-shadow-glow' : 'text-[#D4AF37] group-hover:scale-110' }} transition-all duration-200"></i>
                        <span class="flex-1 font-medium text-sm">Department Dashboard</span>
                    </a>
                    
                @elseif($userRole == 5)
                    <a href="{{ route('college.dashboard') }}" 
                       class="flex items-center gap-3 px-4 py-3 text-white/85 rounded-lg transition-all duration-200 group {{ request()->routeIs('college.dashboard') ? 'bg-white/15 shadow-lg border-l-4 border-[#D4AF37]' : 'hover:bg-white/10 hover:translate-x-1' }}">
                        <i class="fa fa-university w-5 text-center {{ request()->routeIs('college.dashboard') ? 'text-[#FFD700] drop-shadow-glow' : 'text-[#D4AF37] group-hover:scale-110' }} transition-all duration-200"></i>
                        <span class="flex-1 font-medium text-sm">College Dashboard</span>
                    </a>
                @endif
            </div>

            {{-- Admin Management Section --}}
            @if($userRole == 2)
                <!-- Divider -->
                <div class="h-px bg-gradient-to-r from-transparent via-white/15 to-transparent my-3 mx-4"></div>
                
                <div class="mb-2">
                    <h4 class="px-4 text-white/40 text-[0.65rem] font-bold uppercase tracking-widest mb-2">Management</h4>
                    
                    <a href="{{ route('admin.applications') }}" 
                       class="flex items-center gap-3 px-4 py-3 text-white/85 rounded-lg transition-all duration-200 group {{ request()->routeIs('admin.applications*') ? 'bg-white/15 shadow-lg border-l-4 border-[#D4AF37]' : 'hover:bg-white/10 hover:translate-x-1' }}">
                        <i class="fa fa-file-text w-5 text-center {{ request()->routeIs('admin.applications*') ? 'text-[#FFD700] drop-shadow-glow' : 'text-[#D4AF37] group-hover:scale-110' }} transition-all duration-200"></i>
                        <span class="flex-1 font-medium text-sm">Application Forms</span>
                    </a>

                    <a href="{{ route('admin.accepted.applicants') }}" 
                       class="flex items-center gap-3 px-4 py-3 text-white/85 rounded-lg transition-all duration-200 group {{ request()->routeIs('admin.accepted.applicants*') ? 'bg-white/15 shadow-lg border-l-4 border-[#D4AF37]' : 'hover:bg-white/10 hover:translate-x-1' }}">
                        <i class="fa fa-users w-5 text-center {{ request()->routeIs('admin.accepted.applicants*') ? 'text-[#FFD700] drop-shadow-glow' : 'text-[#D4AF37] group-hover:scale-110' }} transition-all duration-200"></i>
                        <span class="flex-1 font-medium text-sm">Accepted Applicants</span>
                    </a>

                    <a href="{{ route('admin.announcement.create') }}" 
                       class="flex items-center gap-3 px-4 py-3 text-white/85 rounded-lg transition-all duration-200 group {{ request()->routeIs('admin.announcement*') ? 'bg-white/15 shadow-lg border-l-4 border-[#D4AF37]' : 'hover:bg-white/10 hover:translate-x-1' }}">
                        <i class="fa fa-bullhorn w-5 text-center {{ request()->routeIs('admin.announcement*') ? 'text-[#FFD700] drop-shadow-glow' : 'text-[#D4AF37] group-hover:scale-110' }} transition-all duration-200"></i>
                        <span class="flex-1 font-medium text-sm">Announcements</span>
                    </a>
                </div>

                <!-- Divider -->
                <div class="h-px bg-gradient-to-r from-transparent via-white/15 to-transparent my-3 mx-4"></div>
                
                <div class="mb-2">
                    <h4 class="px-4 text-white/40 text-[0.65rem] font-bold uppercase tracking-widest mb-2">Settings</h4>
                    
                    <a href="{{ route('admin.slider.index') }}" 
                       class="flex items-center gap-3 px-4 py-3 text-white/85 rounded-lg transition-all duration-200 group {{ request()->routeIs('admin.slider*') ? 'bg-white/15 shadow-lg border-l-4 border-[#D4AF37]' : 'hover:bg-white/10 hover:translate-x-1' }}">
                        <i class="fa fa-image w-5 text-center {{ request()->routeIs('admin.slider*') ? 'text-[#FFD700] drop-shadow-glow' : 'text-[#D4AF37] group-hover:scale-110' }} transition-all duration-200"></i>
                        <span class="flex-1 font-medium text-sm">Manage Sliders</span>
                    </a>

                    <a href="{{ route('admin.users.index') }}" 
                       class="flex items-center gap-3 px-4 py-3 text-white/85 rounded-lg transition-all duration-200 group {{ request()->routeIs('admin.users*') ? 'bg-white/15 shadow-lg border-l-4 border-[#D4AF37]' : 'hover:bg-white/10 hover:translate-x-1' }}">
                        <i class="fa fa-user w-5 text-center {{ request()->routeIs('admin.users*') ? 'text-[#FFD700] drop-shadow-glow' : 'text-[#D4AF37] group-hover:scale-110' }} transition-all duration-200"></i>
                        <span class="flex-1 font-medium text-sm">User Management</span>
                    </a>

                    <a href="{{ route('admin.settings.index') }}" 
                       class="flex items-center gap-3 px-4 py-3 text-white/85 rounded-lg transition-all duration-200 group {{ request()->routeIs('admin.settings*') ? 'bg-white/15 shadow-lg border-l-4 border-[#D4AF37]' : 'hover:bg-white/10 hover:translate-x-1' }}">
                        <i class="fas fa-gear w-5 text-center {{ request()->routeIs('admin.settings*') ? 'text-[#FFD700] drop-shadow-glow' : 'text-[#D4AF37] group-hover:scale-110' }} transition-all duration-200"></i>
                        <span class="flex-1 font-medium text-sm">System Settings</span>
                    </a>
                </div>
            @endif

            <!-- Divider -->
            <div class="h-px bg-gradient-to-r from-transparent via-white/15 to-transparent my-3 mx-4"></div>

            {{-- Logout --}}
            <a href="{{ route('logout') }}" 
               onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
               class="flex items-center gap-3 px-4 py-3 text-white/70 rounded-lg transition-all duration-200 hover:bg-red-500/20 hover:text-red-300 group mt-2">
                <i class="fas fa-right-from-bracket w-5 text-center text-red-300 group-hover:scale-110 transition-all duration-200"></i>
                <span class="flex-1 font-medium text-sm">Logout</span>
            </a>

        </nav>

        {{-- Footer --}}
        <div class="relative border-t border-white/10 px-5 py-4">
            <p class="text-center text-white/50 text-[0.7rem] italic">
                <span class="text-[#D4AF37] font-semibold">CLSU</span> – Sieving for Excellence
            </p>
        </div>

    </div>
</aside>

<!-- Logout Form -->
<form id="logout-form" action="{{ route('logout') }}" method="POST" class="hidden">
    @csrf
</form>

<!-- Sidebar Close Button Script -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const sidebarCloseButton = document.getElementById('sidebar-close-button');
    const sidebar = document.getElementById('mobile-sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    const menuButton = document.getElementById('mobile-menu-button');
    const openIcon = document.getElementById('menu-open-icon');
    const closeIcon = document.getElementById('menu-close-icon');
    
    if (sidebarCloseButton) {
        sidebarCloseButton.addEventListener('click', function() {
            // Close sidebar
            sidebar.classList.remove('translate-x-0');
            sidebar.classList.add('-translate-x-full');
            overlay.classList.add('opacity-0');
            setTimeout(() => {
                overlay.classList.add('hidden');
            }, 300);
            menuButton.setAttribute('aria-expanded', 'false');
            openIcon.classList.remove('hidden');
            closeIcon.classList.add('hidden');
            document.body.classList.remove('overflow-hidden');
        });
    }
});
</script>

<style>
.drop-shadow-glow {
    filter: drop-shadow(0 0 4px rgba(255, 215, 0, 0.5));
}

.bg-gradient-radial {
    background: radial-gradient(circle, var(--tw-gradient-stops));
}
</style>