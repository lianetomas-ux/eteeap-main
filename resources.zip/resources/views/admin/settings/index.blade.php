@extends('layouts.admin') 

@section('content')
{{-- Tailwind CSS CDN --}}
<script src="https://cdn.tailwindcss.com"></script>
<script>
    tailwind.config = {
        theme: {
            extend: {
                colors: {
                    'clsu-green': '#087a29',
                    'clsu-green-dark': '#065a1f',
                    'clsu-green-light': '#0a9432',
                    'clsu-yellow': '#F9B233',
                    'clsu-gold': '#D4AF37',
                }
            }
        }
    }
</script>

<style>
    @import url('https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@300;400;500;600;700;800&family=Playfair+Display:wght@500;600;700&display=swap');
    
    .font-franklin { font-family: 'Libre Franklin', sans-serif; }
    .font-playfair { font-family: 'Playfair Display', serif; }
</style>

<div class="min-h-screen bg-gradient-to-br from-green-50 via-white to-yellow-50 p-4 md:p-6 font-franklin">
    <div class="max-w-3xl mx-auto">
        
        {{-- Settings Card --}}
        <div class="bg-white rounded-2xl shadow-lg overflow-hidden border border-green-100">
            {{-- Green Header --}}
            <div class="bg-gradient-to-r from-clsu-green to-clsu-green-dark p-6 relative overflow-hidden">
                {{-- Decorative circles --}}
                <div class="absolute top-0 right-0 w-32 h-32 bg-clsu-yellow/10 rounded-full -translate-y-1/2 translate-x-1/2"></div>
                <div class="absolute bottom-0 left-1/4 w-16 h-16 bg-white/5 rounded-full translate-y-1/2"></div>
                
                <div class="relative z-10 flex items-center gap-4">
                    <div class="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center">
                        <i class="fa fa-cogs text-clsu-yellow text-2xl"></i>
                    </div>
                    <div>
                        <h1 class="text-2xl md:text-3xl font-playfair font-bold text-white">System Settings</h1>
                        <p class="text-green-100 text-sm">Configure your application settings</p>
                    </div>
                </div>
                
                {{-- Gold accent line --}}
                <div class="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-clsu-yellow via-clsu-gold to-clsu-yellow"></div>
            </div>
            
            {{-- Form Section --}}
            <div class="p-6 md:p-8">
                
                {{-- Success Alert --}}
                @if(session('success'))
                <div class="mb-6 p-4 bg-green-50 border-l-4 border-clsu-green rounded-r-xl flex items-center gap-3 animate-fade-in">
                    <div class="w-10 h-10 bg-clsu-green rounded-full flex items-center justify-center flex-shrink-0">
                        <i class="fa fa-check text-white"></i>
                    </div>
                    <div>
                        <p class="font-semibold text-clsu-green-dark">Success!</p>
                        <p class="text-sm text-green-700">{{ session('success') }}</p>
                    </div>
                </div>
                @endif

                {{-- Error Alert --}}
                @if(session('error'))
                <div class="mb-6 p-4 bg-red-50 border-l-4 border-red-500 rounded-r-xl flex items-center gap-3">
                    <div class="w-10 h-10 bg-red-500 rounded-full flex items-center justify-center flex-shrink-0">
                        <i class="fa fa-times text-white"></i>
                    </div>
                    <div>
                        <p class="font-semibold text-red-700">Error!</p>
                        <p class="text-sm text-red-600">{{ session('error') }}</p>
                    </div>
                </div>
                @endif

                <form action="{{ route('admin.settings.update') }}" method="POST" enctype="multipart/form-data" class="space-y-6">
                    @csrf
                    
                    {{-- System Domain --}}
                    <div class="group">
                        <label for="system_domain" class="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-2">
                            <span class="w-8 h-8 rounded-lg bg-clsu-green/10 flex items-center justify-center">
                                <i class="fa fa-globe text-clsu-green text-sm"></i>
                            </span>
                            System Domain
                        </label>
                        <input 
                            type="text" 
                            name="system_domain" 
                            id="system_domain" 
                            class="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-clsu-green focus:ring focus:ring-clsu-green/20 transition-all outline-none"
                            value="{{ old('system_domain', $settings['system_domain'] ?? '') }}" 
                            placeholder="e.g. http://eteeap.clsu.edu.ph">
                        <p class="mt-1.5 text-xs text-gray-500 ml-10">The base URL of your application</p>
                    </div>
                    
                    {{-- System Title --}}
                    <div class="group">
                        <label for="system_title" class="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-2">
                            <span class="w-8 h-8 rounded-lg bg-clsu-yellow/20 flex items-center justify-center">
                                <i class="fa fa-font text-clsu-gold text-sm"></i>
                            </span>
                            System Title
                        </label>
                        <input 
                            type="text" 
                            name="system_title" 
                            id="system_title"
                            class="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-clsu-green focus:ring focus:ring-clsu-green/20 transition-all outline-none"
                            value="{{ old('system_title', $settings['system_title'] ?? '') }}"
                            placeholder="e.g. CLSU ETEEAP Application System">
                        <p class="mt-1.5 text-xs text-gray-500 ml-10">This will be displayed in the browser tab and header</p>
                    </div>

                    {{-- System Logo --}}
                    <div class="group">
                        <label class="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-2">
                            <span class="w-8 h-8 rounded-lg bg-indigo-100 flex items-center justify-center">
                                <i class="fa fa-image text-indigo-600 text-sm"></i>
                            </span>
                            System Logo
                        </label>
                        
                        <div class="ml-10">
                            {{-- Current Logo Preview --}}
                            @if(!empty($settings['system_logo']))
                            <div class="mb-4 p-4 bg-gray-50 rounded-xl border-2 border-dashed border-gray-200">
                                <p class="text-xs text-gray-500 mb-2 font-medium">Current Logo:</p>
                                <div class="flex items-center gap-4">
                                    <div class="w-20 h-20 bg-white rounded-xl shadow-sm flex items-center justify-center p-2 border">
                                        <img src="{{ asset($settings['system_logo']) }}" alt="Current Logo" class="max-h-full max-w-full object-contain">
                                    </div>
                                    <div class="text-sm text-gray-600">
                                        <p class="font-medium">{{ basename($settings['system_logo']) }}</p>
                                        <p class="text-xs text-gray-400">Upload a new file to replace</p>
                                    </div>
                                </div>
                            </div>
                            @endif
                            
                            {{-- File Upload --}}
                            <div class="relative">
                                <input 
                                    type="file" 
                                    name="system_logo" 
                                    id="system_logo"
                                    accept="image/*"
                                    class="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                                    onchange="previewLogo(this)">
                                <div class="flex items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-xl hover:border-clsu-green hover:bg-green-50/50 transition-all cursor-pointer" id="upload-area">
                                    <div class="text-center">
                                        <div class="w-12 h-12 mx-auto mb-2 rounded-full bg-gray-100 flex items-center justify-center">
                                            <i class="fa fa-cloud-upload text-gray-400 text-xl"></i>
                                        </div>
                                        <p class="text-sm font-medium text-gray-600">Click to upload logo</p>
                                        <p class="text-xs text-gray-400 mt-1">PNG, JPG, GIF up to 2MB</p>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- New Logo Preview --}}
                            <div id="logo-preview" class="hidden mt-4 p-4 bg-green-50 rounded-xl border border-clsu-green/30">
                                <p class="text-xs text-clsu-green font-medium mb-2">New Logo Preview:</p>
                                <div class="flex items-center gap-4">
                                    <div class="w-20 h-20 bg-white rounded-xl shadow-sm flex items-center justify-center p-2 border border-clsu-green/30">
                                        <img id="preview-image" src="" alt="Preview" class="max-h-full max-w-full object-contain">
                                    </div>
                                    <div>
                                        <p id="preview-name" class="text-sm font-medium text-gray-700"></p>
                                        <button type="button" onclick="clearPreview()" class="text-xs text-red-500 hover:text-red-700 mt-1">
                                            <i class="fa fa-times mr-1"></i> Remove
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {{-- Divider --}}
                    <div class="border-t border-gray-200 pt-6"></div>

                    {{-- Submit Button --}}
                    <div class="flex items-center justify-between">
                        <p class="text-xs text-gray-500">
                            <i class="fa fa-info-circle mr-1"></i>
                            Changes will take effect immediately
                        </p>
                        <button 
                            type="submit" 
                            class="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold text-white bg-gradient-to-r from-clsu-green to-clsu-green-dark hover:from-clsu-green-dark hover:to-clsu-green transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5">
                            <i class="fa fa-save"></i>
                            Save Settings
                        </button>
                    </div>
                </form>
            </div>
            
            {{-- Footer --}}
            <div class="bg-gradient-to-r from-clsu-green to-clsu-green-dark px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-2">
                <p class="text-green-100 text-sm italic">Sieving for Excellence — Central Luzon State University</p>
                <p class="text-clsu-yellow font-semibold text-sm flex items-center gap-2">
                    <i class="fa fa-university"></i>
                    CLSU ETEEAP
                </p>
            </div>
        </div>
        
    </div>
</div>

{{-- JavaScript for Logo Preview --}}
<script>
function previewLogo(input) {
    const preview = document.getElementById('logo-preview');
    const previewImage = document.getElementById('preview-image');
    const previewName = document.getElementById('preview-name');
    const uploadArea = document.getElementById('upload-area');
    
    if (input.files && input.files[0]) {
        const file = input.files[0];
        const reader = new FileReader();
        
        reader.onload = function(e) {
            previewImage.src = e.target.result;
            previewName.textContent = file.name;
            preview.classList.remove('hidden');
            uploadArea.classList.add('border-clsu-green', 'bg-green-50/50');
        }
        
        reader.readAsDataURL(file);
    }
}

function clearPreview() {
    const input = document.getElementById('system_logo');
    const preview = document.getElementById('logo-preview');
    const uploadArea = document.getElementById('upload-area');
    
    input.value = '';
    preview.classList.add('hidden');
    uploadArea.classList.remove('border-clsu-green', 'bg-green-50/50');
}
</script>

<style>
@keyframes fade-in {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}

.animate-fade-in {
    animation: fade-in 0.3s ease-out;
}
</style>
@endsection