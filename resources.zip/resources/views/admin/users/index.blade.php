@extends('layouts.admin')

@section('content')

<div class="min-h-screen bg-gradient-to-br from-[#004422] to-[#006633] py-4 md:py-6 lg:py-8 px-2 md:px-4">
    <div class="container mx-auto max-w-7xl">
        <!-- Page Title -->
        <h1 class="text-white text-xl md:text-2xl lg:text-3xl xl:text-4xl font-bold text-center mb-4 md:mb-6 lg:mb-8 drop-shadow-lg px-2">
            <span class="text-[#FFD700]">ETEEAP</span> User Management System
        </h1>

        @php
            $roles = [
                1 => ['name' => 'Applicant', 'avatar' => 'from-[#9b59b6] to-[#8e44ad]', 'role' => 'bg-[#f3e5f5] text-[#8e44ad]', 'icon' => 'fa-user-graduate'],
                2 => ['name' => 'Admin', 'avatar' => 'from-[#e74c3c] to-[#c0392b]', 'role' => 'bg-[#fde8e8] text-[#c0392b]', 'icon' => 'fa-user-shield'],
                3 => ['name' => 'Assessor', 'avatar' => 'from-[#00994d] to-[#006633]', 'role' => 'bg-[#e8f5e9] text-[#006633]', 'icon' => 'fa-clipboard-check'],
                4 => ['name' => 'Dept. Coordinator', 'avatar' => 'from-[#f39c12] to-[#e67e22]', 'role' => 'bg-[#fff8e1] text-[#e67e22]', 'icon' => 'fa-building'],
                5 => ['name' => 'College Coordinator', 'avatar' => 'from-[#3498db] to-[#2980b9]', 'role' => 'bg-[#e3f2fd] text-[#2980b9]', 'icon' => 'fa-university'],
            ];
            
            $roleCounts = [
                'all' => count($users),
                '1' => $users->where('role', 1)->count(),
                '2' => $users->where('role', 2)->count(),
                '3' => $users->where('role', 3)->count(),
                '4' => $users->where('role', 4)->count(),
                '5' => $users->where('role', 5)->count(),
            ];
        @endphp

        <!-- Stats Cards -->
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 md:gap-3 lg:gap-4 mb-4 md:mb-6 lg:mb-8">
            <div class="bg-white rounded-xl md:rounded-2xl p-3 md:p-4 lg:p-5 text-center transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_10px_30px_rgba(0,0,0,0.2)] border-b-4 border-[#FFD700]">
                <div class="text-2xl md:text-3xl lg:text-4xl font-bold text-[#006633] mb-1">{{ $roleCounts['all'] }}</div>
                <div class="text-gray-600 text-[9px] md:text-[10px] lg:text-xs uppercase tracking-wider">Total Users</div>
            </div>
            <div class="bg-white rounded-xl md:rounded-2xl p-3 md:p-4 lg:p-5 text-center transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_10px_30px_rgba(0,0,0,0.2)] border-b-4 border-[#FFD700]">
                <div class="text-2xl md:text-3xl lg:text-4xl font-bold text-[#006633] mb-1">{{ $roleCounts['1'] }}</div>
                <div class="text-gray-600 text-[9px] md:text-[10px] lg:text-xs uppercase tracking-wider">Applicants</div>
            </div>
            <div class="bg-white rounded-xl md:rounded-2xl p-3 md:p-4 lg:p-5 text-center transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_10px_30px_rgba(0,0,0,0.2)] border-b-4 border-[#FFD700]">
                <div class="text-2xl md:text-3xl lg:text-4xl font-bold text-[#006633] mb-1">{{ $roleCounts['2'] }}</div>
                <div class="text-gray-600 text-[9px] md:text-[10px] lg:text-xs uppercase tracking-wider">Admins</div>
            </div>
            <div class="bg-white rounded-xl md:rounded-2xl p-3 md:p-4 lg:p-5 text-center transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_10px_30px_rgba(0,0,0,0.2)] border-b-4 border-[#FFD700]">
                <div class="text-2xl md:text-3xl lg:text-4xl font-bold text-[#006633] mb-1">{{ $roleCounts['3'] }}</div>
                <div class="text-gray-600 text-[9px] md:text-[10px] lg:text-xs uppercase tracking-wider leading-tight">Assessors</div>
            </div>
            <div class="bg-white rounded-xl md:rounded-2xl p-3 md:p-4 lg:p-5 text-center transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_10px_30px_rgba(0,0,0,0.2)] border-b-4 border-[#FFD700]">
                <div class="text-2xl md:text-3xl lg:text-4xl font-bold text-[#006633] mb-1">{{ $roleCounts['4'] }}</div>
                <div class="text-gray-600 text-[9px] md:text-[10px] lg:text-xs uppercase tracking-wider leading-tight">Dept.<br class="sm:hidden"> Coord.</div>
            </div>
            <div class="bg-white rounded-xl md:rounded-2xl p-3 md:p-4 lg:p-5 text-center transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_10px_30px_rgba(0,0,0,0.2)] border-b-4 border-[#FFD700]">
                <div class="text-2xl md:text-3xl lg:text-4xl font-bold text-[#006633] mb-1">{{ $roleCounts['5'] }}</div>
                <div class="text-gray-600 text-[9px] md:text-[10px] lg:text-xs uppercase tracking-wider leading-tight">College<br class="sm:hidden"> Coord.</div>
            </div>
        </div>

        <!-- Main Card -->
        <div class="bg-white rounded-[20px] overflow-hidden shadow-[0_15px_50px_rgba(0,0,0,0.2)]">
            <!-- Header with Search -->
            <div class="bg-gradient-to-r from-[#006633] to-[#00994d] p-4 md:p-5 lg:p-8 flex flex-wrap justify-between items-center gap-3 md:gap-4">
                <h4 class="text-white text-base md:text-xl lg:text-2xl font-semibold m-0">Registered Users</h4>
                <div class="relative w-full sm:w-auto sm:min-w-[250px] md:min-w-[300px]">
                    <i class="fa fa-search absolute left-3 md:left-4 lg:left-5 top-1/2 -translate-y-1/2 text-[#006633] text-sm md:text-base"></i>
                    <input type="text" id="searchBar" placeholder="Search by name or email..." class="w-full pl-9 md:pl-11 lg:pl-12 pr-3 md:pr-4 lg:pr-5 py-2 md:py-2.5 lg:py-3.5 rounded-full text-xs md:text-sm lg:text-base bg-white/90 focus:outline-none focus:bg-white focus:ring-4 focus:ring-[#FFD700] transition-all duration-300">
                </div>
            </div>

            <!-- Filter Tabs -->
            <div class="flex bg-gray-100 p-1.5 md:p-2 lg:p-2.5 gap-1 overflow-x-auto scrollbar-thin scrollbar-thumb-gray-300">
                <button class="filter-tab px-2 md:px-3 lg:px-5 py-1.5 md:py-2 lg:py-2.5 rounded-lg font-medium text-[10px] md:text-xs lg:text-sm text-gray-600 transition-all duration-300 hover:bg-gray-200 whitespace-nowrap bg-[#006633] text-white" onclick="filterUsers('all', this)">
                    All <span class="inline-block bg-black/10 px-1.5 md:px-2 py-0.5 rounded-full text-[9px] md:text-[10px] lg:text-xs ml-0.5 md:ml-1">{{ $roleCounts['all'] }}</span>
                </button>
                <button class="filter-tab px-2 md:px-3 lg:px-5 py-1.5 md:py-2 lg:py-2.5 rounded-lg font-medium text-[10px] md:text-xs lg:text-sm text-gray-600 transition-all duration-300 hover:bg-gray-200 whitespace-nowrap" onclick="filterUsers('2', this)">
                    Admin <span class="inline-block bg-black/10 px-1.5 md:px-2 py-0.5 rounded-full text-[9px] md:text-[10px] lg:text-xs ml-0.5 md:ml-1">{{ $roleCounts['2'] }}</span>
                </button>
                <button class="filter-tab px-2 md:px-3 lg:px-5 py-1.5 md:py-2 lg:py-2.5 rounded-lg font-medium text-[10px] md:text-xs lg:text-sm text-gray-600 transition-all duration-300 hover:bg-gray-200 whitespace-nowrap" onclick="filterUsers('3', this)">
                    Assessor <span class="inline-block bg-black/10 px-1.5 md:px-2 py-0.5 rounded-full text-[9px] md:text-[10px] lg:text-xs ml-0.5 md:ml-1">{{ $roleCounts['3'] }}</span>
                </button>
                <button class="filter-tab px-2 md:px-3 lg:px-5 py-1.5 md:py-2 lg:py-2.5 rounded-lg font-medium text-[10px] md:text-xs lg:text-sm text-gray-600 transition-all duration-300 hover:bg-gray-200 whitespace-nowrap" onclick="filterUsers('4', this)">
                    Dept. Coord. <span class="inline-block bg-black/10 px-1.5 md:px-2 py-0.5 rounded-full text-[9px] md:text-[10px] lg:text-xs ml-0.5 md:ml-1">{{ $roleCounts['4'] }}</span>
                </button>
                <button class="filter-tab px-2 md:px-3 lg:px-5 py-1.5 md:py-2 lg:py-2.5 rounded-lg font-medium text-[10px] md:text-xs lg:text-sm text-gray-600 transition-all duration-300 hover:bg-gray-200 whitespace-nowrap" onclick="filterUsers('5', this)">
                    College Coord. <span class="inline-block bg-black/10 px-1.5 md:px-2 py-0.5 rounded-full text-[9px] md:text-[10px] lg:text-xs ml-0.5 md:ml-1">{{ $roleCounts['5'] }}</span>
                </button>
                <button class="filter-tab px-2 md:px-3 lg:px-5 py-1.5 md:py-2 lg:py-2.5 rounded-lg font-medium text-[10px] md:text-xs lg:text-sm text-gray-600 transition-all duration-300 hover:bg-gray-200 whitespace-nowrap" onclick="filterUsers('1', this)">
                    Applicant <span class="inline-block bg-black/10 px-1.5 md:px-2 py-0.5 rounded-full text-[9px] md:text-[10px] lg:text-xs ml-0.5 md:ml-1">{{ $roleCounts['1'] }}</span>
                </button>
            </div>

            <!-- User Grid -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4 lg:gap-5 p-3 md:p-4 lg:p-6 xl:p-8 bg-[#f8f9e8]" id="userGrid">
                @forelse($users as $user)
                    <div class="user-card bg-white rounded-xl md:rounded-2xl p-3 md:p-4 lg:p-5 flex items-center gap-2 md:gap-3 lg:gap-4 transition-all duration-300 border-2 border-transparent hover:border-[#FFD700] hover:shadow-lg hover:translate-x-1 relative overflow-hidden" data-role="{{ $user->role }}">
                        <div class="absolute top-0 left-0 w-1 md:w-1.5 h-full bg-[#006633]"></div>
                        
                        <div class="w-10 h-10 md:w-12 md:h-12 lg:w-[60px] lg:h-[60px] rounded-full flex items-center justify-center text-base md:text-lg lg:text-2xl font-bold text-white flex-shrink-0 bg-gradient-to-br {{ $roles[$user->role]['avatar'] ?? 'from-[#9b59b6] to-[#8e44ad]' }}">
                            {{ strtoupper(substr($user->name, 0, 1)) }}
                        </div>
                        
                        <div class="flex-1 min-w-0">
                            <div class="font-semibold text-[#333] text-xs md:text-sm lg:text-base mb-0.5 truncate" title="{{ $user->name }}">{{ $user->name }}</div>
                            <div class="text-gray-500 text-[10px] md:text-xs lg:text-sm truncate" title="{{ $user->email }}">{{ $user->email }}</div>
                            <span class="inline-block text-[9px] md:text-[10px] lg:text-xs px-1.5 md:px-2 lg:px-2.5 py-0.5 md:py-1 rounded-full font-semibold uppercase tracking-wide mt-1 md:mt-2 {{ $roles[$user->role]['role'] ?? 'bg-[#f3e5f5] text-[#8e44ad]' }}">
                                {{ $roles[$user->role]['name'] ?? 'Unknown' }}
                            </span>
                        </div>
                        
                        <div class="flex flex-col gap-2 flex-shrink-0">
                            <a href="{{ route('admin.users.edit', $user->id) }}" class="bg-[#FFD700] text-[#004422] px-2 md:px-3 lg:px-4 py-1.5 md:py-2 lg:py-2.5 rounded-lg font-semibold text-[10px] md:text-xs lg:text-sm transition-all duration-300 hover:bg-[#006633] hover:text-white text-center no-underline whitespace-nowrap">
                                <i class="fas fa-pen mr-0.5 md:mr-1"></i> <span class="hidden sm:inline">Edit</span><span class="sm:hidden">Edit</span>
                            </a>
                        </div>
                    </div>
                @empty
                    <div class="col-span-full text-center py-12 md:py-16 text-gray-400">
                        <i class="fas fa-user-slash text-5xl md:text-6xl mb-4"></i>
                        <h4 class="text-lg md:text-xl font-semibold mb-2">No Users Found</h4>
                        <p class="text-sm md:text-base">There are no registered users in the system yet.</p>
                    </div>
                @endforelse
                
                <div class="hidden col-span-full text-center py-10 md:py-12 text-gray-400" id="noResults">
                    <i class="fas fa-search text-4xl md:text-5xl mb-3"></i>
                    <h5 class="text-base md:text-lg font-semibold mb-1">No matching users found</h5>
                    <p class="text-xs md:text-sm">Try adjusting your search or filter criteria</p>
                </div>
            </div>

            {{-- Pagination Controls --}}
            <div class="flex flex-col sm:flex-row items-center justify-between gap-4 px-4 md:px-6 lg:px-8 py-4 md:py-5 bg-gradient-to-b from-white to-[#f8f9e8] border-t border-gray-200">
                <div class="text-xs md:text-sm text-gray-600 order-1">
                    Showing <span id="page-start" class="font-semibold">1</span> to <span id="page-end" class="font-semibold">9</span> of <span id="page-total" class="font-semibold">{{ $users->count() }}</span> users
                </div>
                <div class="flex items-center gap-1 md:gap-2 order-2">
                    <button type="button" onclick="changePage(-1)" class="px-2 md:px-3 py-1.5 md:py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm md:text-base" id="prev-btn">
                        <i class="fa fa-chevron-left"></i>
                    </button>
                    <div id="page-numbers" class="flex items-center gap-1"></div>
                    <button type="button" onclick="changePage(1)" class="px-2 md:px-3 py-1.5 md:py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm md:text-base" id="next-btn">
                        <i class="fa fa-chevron-right"></i>
                    </button>
                </div>
            </div>

            <!-- Footer -->
            <div class="bg-[#006633] text-white px-3 md:px-4 lg:px-6 py-2.5 md:py-3 lg:py-4 flex flex-col sm:flex-row justify-between items-center gap-1.5 md:gap-2 text-[10px] md:text-xs lg:text-sm">
                <span>User Count: <span id="visibleCount">{{ $roleCounts['all'] }}</span></span>
                <div class="flex items-center gap-1.5 md:gap-2 lg:gap-2.5">
                    <i class="fas fa-university text-xs md:text-sm"></i>
                    <span class="text-center sm:text-left">Central Luzon State University</span>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    let currentFilter = 'all';
    let currentPage = 1;
    const ITEMS_PER_PAGE = 9;

    function filterUsers(role, btn) {
        currentFilter = role;
        
        // Update active tab
        document.querySelectorAll('.filter-tab').forEach(tab => {
            tab.classList.remove('bg-[#006633]', 'text-white');
            tab.classList.add('text-gray-600');
        });
        btn.classList.remove('text-gray-600');
        btn.classList.add('bg-[#006633]', 'text-white');

        // Reset to page 1 when filter changes
        currentPage = 1;
        applyFiltersAndPagination();
    }

    function applyFiltersAndPagination() {
        const searchValue = document.getElementById('searchBar').value.toLowerCase();
        const cards = document.querySelectorAll('.user-card');
        let visibleCards = [];

        // First, filter cards based on role and search
        cards.forEach(card => {
            const matchesRole = currentFilter === 'all' || card.getAttribute('data-role') === currentFilter;
            const text = card.innerText.toLowerCase();
            const matchesSearch = text.includes(searchValue);

            if (matchesRole && matchesSearch) {
                visibleCards.push(card);
            }
        });

        // Hide all cards first
        cards.forEach(card => card.style.display = 'none');

        // Calculate pagination
        const totalItems = visibleCards.length;
        const totalPages = Math.ceil(totalItems / ITEMS_PER_PAGE);
        const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
        const endIndex = Math.min(startIndex + ITEMS_PER_PAGE, totalItems);

        // Show only cards for current page
        for (let i = startIndex; i < endIndex; i++) {
            if (visibleCards[i]) {
                visibleCards[i].style.display = '';
            }
        }

        // Update pagination info
        document.getElementById('page-start').textContent = totalItems > 0 ? startIndex + 1 : 0;
        document.getElementById('page-end').textContent = endIndex;
        document.getElementById('page-total').textContent = totalItems;

        // Update page buttons
        updatePageButtons(totalPages);

        // Update prev/next buttons
        document.getElementById('prev-btn').disabled = currentPage <= 1;
        document.getElementById('next-btn').disabled = currentPage >= totalPages;

        // Show/hide no results message
        const noResults = document.getElementById('noResults');
        if (totalItems === 0 && cards.length > 0) {
            noResults.classList.remove('hidden');
            noResults.classList.add('block');
        } else {
            noResults.classList.add('hidden');
            noResults.classList.remove('block');
        }

        // Update count
        document.getElementById('visibleCount').textContent = totalItems;
    }

    function updatePageButtons(totalPages) {
        const container = document.getElementById('page-numbers');
        container.innerHTML = '';

        // Show max 5 page buttons on desktop, 3 on mobile
        const isMobile = window.innerWidth < 640;
        const maxButtons = isMobile ? 3 : 5;
        
        let startPage = Math.max(1, currentPage - Math.floor(maxButtons / 2));
        let endPage = Math.min(totalPages, startPage + maxButtons - 1);

        if (endPage - startPage < maxButtons - 1) {
            startPage = Math.max(1, endPage - maxButtons + 1);
        }

        for (let i = startPage; i <= endPage; i++) {
            const pageBtn = document.createElement('button');
            pageBtn.type = 'button';
            pageBtn.textContent = i;
            pageBtn.className = `px-2 md:px-3 py-1.5 md:py-2 rounded-lg text-xs md:text-sm font-semibold transition-colors ${
                i === currentPage 
                    ? 'bg-[#006633] text-white' 
                    : 'border border-gray-300 text-gray-700 hover:bg-gray-50'
            }`;
            pageBtn.onclick = () => goToPage(i);
            container.appendChild(pageBtn);
        }
    }

    function changePage(direction) {
        const cards = document.querySelectorAll('.user-card');
        const searchValue = document.getElementById('searchBar').value.toLowerCase();
        let visibleCount = 0;

        cards.forEach(card => {
            const matchesRole = currentFilter === 'all' || card.getAttribute('data-role') === currentFilter;
            const text = card.innerText.toLowerCase();
            const matchesSearch = text.includes(searchValue);
            if (matchesRole && matchesSearch) visibleCount++;
        });

        const totalPages = Math.ceil(visibleCount / ITEMS_PER_PAGE);
        currentPage = Math.max(1, Math.min(totalPages, currentPage + direction));
        applyFiltersAndPagination();
    }

    function goToPage(pageNumber) {
        currentPage = pageNumber;
        applyFiltersAndPagination();
    }

    // Search functionality
    document.getElementById('searchBar').addEventListener('keyup', function() {
        currentPage = 1; // Reset to page 1 when searching
        applyFiltersAndPagination();
    });

    // Update pagination on window resize
    window.addEventListener('resize', function() {
        applyFiltersAndPagination();
    });

    // Initialize pagination on page load
    document.addEventListener('DOMContentLoaded', function() {
        applyFiltersAndPagination();
    });
</script>
@endsection