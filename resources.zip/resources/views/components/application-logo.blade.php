<!-- resources/views/auth/application-logo.blade.php -->
<!--<div class="wrapper wrapper-content animated fadeInRight">
    <img src="{{ asset('images/row.png') }}" alt="Logo" class="h-16">
</div> -->
