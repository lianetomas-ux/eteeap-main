@extends('emails.layout')

@section('content')
<div class="email-content">
    <h2 style="color: #dc2626; margin-bottom: 20px;">Application Status Update</h2>
    
    <p>Dear {{ $applicant->first_name }} {{ $applicant->middle_name }} {{ $applicant->last_name }},</p>
    
    <p>Thank you for your interest in the Expanded Tertiary Education Equivalency and Accreditation Program (ETEEAP) at Central Luzon State University.</p>
    
    <div class="email-info-box warning">
        <p style="margin: 0; font-weight: 600; color: #991b1b; margin-bottom: 8px;">
            <i class="fas fa-exclamation-triangle" style="margin-right: 8px;"></i>Application Status: Rejected
        </p>
        <p style="margin: 0; font-size: 14px; color: #7f1d1d;">
            We regret to inform you that your application has been rejected after careful review by our assessment committee.
        </p>
    </div>
    
    @if (!empty($applicant->remarks))
    <div style="background: #fef2f2; border-left: 4px solid #dc2626; padding: 20px; margin: 20px 0; border-radius: 0 8px 8px 0;">
        <p style="margin: 0; font-weight: 600; color: #991b1b; margin-bottom: 10px;">Remarks from the Committee:</p>
        <p style="margin: 0; color: #7f1d1d; line-height: 1.8;">{{ $applicant->remarks }}</p>
    </div>
    @endif
    
    <p>We understand this may be disappointing news. If you have any questions about this decision or would like to discuss your application further, please don't hesitate to contact our office.</p>
    
    <div style="text-align: center; margin: 30px 0;">
        <a href="{{ url('/') }}" class="email-button" style="background: linear-gradient(135deg, #6b7280 0%, #4b5563 100%);">Visit Our Website</a>
    </div>
    
    <div class="email-divider"></div>
    
    <p style="font-size: 14px; color: #6b7280;">
        We appreciate your interest in CLSU ETEEAP and encourage you to consider reapplying in the future if your circumstances change.
    </p>
    
    <p style="margin-top: 20px;">
        Best regards,<br>
        <strong>ETEEAP Assessment Committee</strong><br>
        Central Luzon State University
    </p>
</div>
@endsection
