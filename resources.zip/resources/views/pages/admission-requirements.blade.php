@extends('layouts.app')

@section('content')
    @include('partials.admission-requirements')
@endsection
