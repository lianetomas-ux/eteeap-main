@extends('layouts.app') 

@section('content')
    @include('partials.mission-vision')
@endsection
