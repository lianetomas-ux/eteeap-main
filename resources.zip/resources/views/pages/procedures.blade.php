@extends('layouts.app') 

@section('content')
    @include('partials.procedures')
@endsection
