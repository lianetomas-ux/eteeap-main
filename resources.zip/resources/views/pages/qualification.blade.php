@extends('layouts.app') 

@section('content')
    @include('partials.qualification')
@endsection
