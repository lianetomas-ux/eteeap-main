@extends('layouts.app')

@section('title', 'Mission & Vision')

@section('content')

<div style="position: relative; min-height: 80vh; overflow: hidden;">

    <div style="
          position: absolute;
          inset: 0;
          background: url('{{ asset('inspinia/img/landing/r.jpg') }}') no-repeat center center;
          background-size: cover;
          z-index: 0;
        ">
        <div style="position: absolute; inset: 0; background: rgba(8, 122, 41, 0.7);"></div>
    </div>

    <div class="container position-relative py-5" style="z-index: 2;" id="mission-vision">
        
        <div class="wrapper wrapper-content animated fadeInRight">

            <div class="row mb-5 mt-4">
                <div class="col-12 text-center">
                    <h2 class="font-weight-bold text-uppercase text-white mb-3">Mission and Vision</h2>
                    <div class="navy-line"></div>
                    <p class="text-white fs-5 opacity-75">The ETEEAP Program's foundation is guided by the following principles:</p>
                </div>
            </div>

            <div class="row justify-content-center mb-4">
                <div class="col-12 col-lg-8">
                    <div class="glass-panel p-5 text-white">
                        <h3 class="mb-3 font-bold text-warning">MISSION</h3>
                        <p class="fs-5 mb-0 text-justify" style="line-height: 1.6;">
                            The Expanded Tertiary Education Equivalency and Accreditation Program (ETEEAP) provides access and opportunities to the formal higher education system for deserving Filipinos with prior experiential learning.
                        </p>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center">
                <div class="col-12 col-lg-8">
                    <div class="glass-panel p-5 text-white">
                        <h3 class="mb-3 font-bold text-warning">VISION</h3>
                        <p class="fs-5 mb-0 text-justify" style="line-height: 1.6;">
                            The ETEEAP envisions a society where individuals’ skills and experiences are recognized, promoting lifelong learning and inclusivity in higher education.
                        </p>
                    </div>
                </div>
            </div>

        </div>
    </div>

</div>

<style>
    /* Glassmorphism Effect for the Boxes */
    .glass-panel {
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        border-radius: 24px;
        border: 1px solid rgba(255, 255, 255, 0.2);
        box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.1);
        transition: transform 0.3s ease;
    }

    .glass-panel:hover {
        transform: translateY(-5px);
        background: rgba(255, 255, 255, 0.15);
    }

    .navy-line {
        background-color: #F9B233; /* CLSU Yellow */
        height: 4px;
        width: 80px;
        margin: 0 auto 1rem auto;
        border-radius: 2px;
    }

    /* Responsive Typography */
    #mission-vision h2 { font-size: 2.5rem; letter-spacing: 1px; }
    #mission-vision h3 { font-size: 1.5rem; letter-spacing: 1px; }
    
    @media (max-width: 768px) {
        #mission-vision h2 { font-size: 1.8rem; }
        .glass-panel { padding: 2rem !important; }
    }
</style>

@include('partials.footer')

@endsection